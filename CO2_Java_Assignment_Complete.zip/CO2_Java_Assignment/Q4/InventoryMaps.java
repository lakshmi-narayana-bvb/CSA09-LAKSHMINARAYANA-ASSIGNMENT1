import java.util.*;
public class InventoryMaps {
 static volatile int sink;
 static long time(Runnable r){long t=System.nanoTime();r.run();return System.nanoTime()-t;}
 public static void main(String[] z){System.out.println("medicines,hash_lookup_100k_ns,tree_lookup_100k_ns,linked_lookup_100k_ns,hash_report_ns,tree_report_ns,linked_report_ns,order_check");
  for(int n:new int[]{1000,10000,50000}){
   Map<String,Integer> h=new HashMap<>(),t=new TreeMap<>(),lh=new LinkedHashMap<>();for(int i=0;i<n;i++){String k=String.format(Locale.ROOT,"MED%06d",i);h.put(k,i);t.put(k,i);lh.put(k,i);}
   String[] keys=h.keySet().toArray(new String[0]); final long[] sum={0};
   long ht=time(()->{long s=0;for(int i=0;i<100000;i++)s+=h.get(keys[i%keys.length]);sum[0]=s;});
   long tt=time(()->{long s=0;for(int i=0;i<100000;i++)s+=t.get(keys[i%keys.length]);sum[0]=s;});
   long lt=time(()->{long s=0;for(int i=0;i<100000;i++)s+=lh.get(keys[i%keys.length]);sum[0]=s;});
   long hr=time(()->{List<String> q=new ArrayList<>(h.keySet());Collections.sort(q);sink=q.size();});
   long tr=time(()->{sink=t.size();for(String k:t.keySet())sink+=k.length();});
   long lr=time(()->{sink=lh.size();for(String k:lh.keySet())sink+=k.length();});
   boolean order=t.keySet().stream().toList().equals(new TreeSet<>(h.keySet()).stream().toList()) && lh.keySet().iterator().next().equals("MED000000");
   System.out.printf(Locale.ROOT,"%d,%d,%d,%d,%d,%d,%d,%s%n",n,ht,tt,lt,hr,tr,lr,order);
  }
  System.out.println("Hashtable is legacy synchronized API; prefer HashMap for unsynchronized access or ConcurrentHashMap for concurrent access.");
 }
}
