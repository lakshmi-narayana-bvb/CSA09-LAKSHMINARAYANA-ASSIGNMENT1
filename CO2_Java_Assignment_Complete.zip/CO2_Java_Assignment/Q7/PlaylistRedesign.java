import java.util.*;
public class PlaylistRedesign {
 static volatile int sink;
 static long time(Runnable r,int reps){long t=System.nanoTime();for(int i=0;i<reps;i++)r.run();return (System.nanoTime()-t)/reps;}
 public static void main(String[]x){System.out.println("n,arraylist_front_remove_ns,arraydeque_front_remove_ns");for(int n:new int[]{1000,10000,50000}){
  List<Integer>base=new ArrayList<>();for(int i=0;i<n;i++)base.add(i);
  long a=time(()->{ArrayList<Integer>c=new ArrayList<>(base);for(int i=0;i<n/4;i++)c.remove(0);sink=c.size();},3);
  long d=time(()->{ArrayDeque<Integer>c=new ArrayDeque<>(base);for(int i=0;i<n/4;i++)c.removeFirst();sink=c.size();},3);
  System.out.printf(Locale.ROOT,"%d,%d,%d%n",n,a,d);
 }}
}
