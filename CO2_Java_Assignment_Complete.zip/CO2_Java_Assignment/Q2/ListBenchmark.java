import java.util.*;
public class ListBenchmark {
 static volatile long sink;
 static long measure(Runnable r,int reps){long t=System.nanoTime();for(int i=0;i<reps;i++)r.run();return (System.nanoTime()-t)/reps;}
 public static void main(String[] x){System.out.println("n,array_get_ns,linked_get_ns,array_iter_ns,linked_iter_ns,array_front_insert_ns,linked_front_insert_ns,arraydeque_end_ops_ns");
  for(int n:new int[]{1000,10000,50000}){
   ArrayList<Integer>a=new ArrayList<>();LinkedList<Integer>l=new LinkedList<>();for(int i=0;i<n;i++){a.add(i);l.add(i);} final int k=n/2;
   long ag=measure(()->{long z=0;for(int i=0;i<2000;i++)z+=a.get(k);sink=z;},5)/2000;
   long lg=measure(()->{long z=0;for(int i=0;i<100;i++)z+=l.get(k);sink=z;},3)/100;
   long ai=measure(()->{long z=0;for(int v:a)z+=v;sink=z;},5); long li=measure(()->{long z=0;for(int v:l)z+=v;sink=z;},5);
   long af=measure(()->{ArrayList<Integer>c=new ArrayList<>(a);c.add(0,-1);},5); long lf=measure(()->{LinkedList<Integer>c=new LinkedList<>(l);c.add(0,-1);},5);
   long dq=measure(()->{ArrayDeque<Integer>d=new ArrayDeque<>();for(int i=0;i<n;i++)d.addLast(i);for(int i=0;i<n/2;i++){d.addFirst(-i);d.removeFirst();}},3);
   System.out.printf(Locale.ROOT,"%d,%d,%d,%d,%d,%d,%d,%d%n",n,ag,lg,ai,li,af,lf,dq);
  }
 }
}
