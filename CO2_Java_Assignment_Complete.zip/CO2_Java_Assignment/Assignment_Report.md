# Programming in Java — Assignment 2 (CO2)

**Name:** Konnipati Lakshmi Narayana  
**Register Number:** 1925260030  
**Java:** OpenJDK 21.0.12.1, 64-bit  
**GitHub:** To be added after creating `CSA09-1925260030-Assignment2`.

> **Measurement note:** The raw figures below were collected by running the included Java benchmark programs in the environment stated above. They are machine- and run-dependent. Re-run on the submission machine and retain its raw output. Memory figures are not claimed where no reliable profiler was used; the report uses object/structure analysis instead.

## Q1 — String, StringBuilder or StringBuffer?

### Prediction and reason
`String` is immutable. Repeated `s = s + field` creates a new result string at each append and copies the existing prefix again. For n similarly sized fields, the total copied characters can grow quadratically, O(n²). `StringBuilder` owns a resizable character buffer and appends amortized O(1) per field, giving O(C) total work for C output characters (often described as O(n) when field lengths are bounded). `StringBuffer` has similar asymptotic behaviour but synchronizes its methods, adding overhead.

### Workloads and measured result
The three workloads were: (1) one short six-field ticket, (2) 1,000 tickets with 50 fields, and (3) 3,000 tickets with 100 fields. Each reported time is a per-ticket average from repeated loops; the `+` run used three repetitions and builder/buffer five after a warm-up pass.

| Fields | Tickets | `+` ns/ticket | StringBuilder ns/ticket | StringBuffer ns/ticket | Estimated `+` intermediate strings |
|---:|---:|---:|---:|---:|---:|
| 6 | 1 | 12,201 | 4,432 | 3,904 | 7 |
| 50 | 1,000 | 20,662 | 1,624 | 1,273 | 51,000 |
| 100 | 3,000 | 38,693 | 1,520 | 5,576 | 303,000 |

The single short ticket has little practical cost, while larger workloads favour mutable builders. The small-workload measurements and the relative order of builder/buffer are affected by JIT compilation, allocation and timing noise; the important result is the scaling and allocation mechanism, not a claim that StringBuffer is always faster. Intermediate string count is an estimate based on one concatenation result per append, not a profiler count.

### Design decision
Use a local `StringBuilder` for each ticket: it is not shared between threads, so synchronization is unnecessary. For a shared booking log, use a proper logging framework or a single-writer/locked design. If a shared mutable buffer is genuinely required, protect the complete compound operation with a lock; `StringBuffer` synchronizes individual methods but does not automatically make a multi-call transaction atomic.

### Alternative: join / joiner / format
`String.join(delimiter, fields)` or `StringJoiner` avoids repeated immutable-prefix concatenation and runs in O(C) output work with O(C) result storage. `String.format` is readable for formatted templates but generally has parsing/formatting overhead; it is not the preferred high-volume builder. Repeated `+` has O(n²) copying for bounded equal-size fields; builder/join have O(C) copying. Builder uses a growing buffer plus final String; repeated `+` creates many short-lived intermediate strings and increases allocation/GC pressure.

## Q2 — ArrayList engineering choice

### Experiment and evidence
The benchmark compares random middle-index access, full iteration, front insertion and a deque end-operation workload at three sizes. The benchmark output is in `results/q2.csv`.

| n | ArrayList get ns/op | LinkedList get ns/op | ArrayList iteration ns | LinkedList iteration ns | ArrayList front insert ns | LinkedList front insert ns |
|---:|---:|---:|---:|---:|---:|---:|
| 1,000 | 74 | 3,505 | 146,412 | 159,224 | 7,573 | 87,514 |
| 10,000 | 44 | 11,895 | 603,549 | 615,996 | 34,001 | 659,085 |
| 50,000 | 59 | 32,226 | 721,655 | 543,441 | 46,500 | 1,064,178 |

These are local timings, not a universal ranking. The test copies the original list before each front insertion, so the displayed front-insert time includes copy cost. `LinkedList.get(k)` is linear and is much slower than indexed ArrayList access. Sequential iteration is O(n) for both; linked nodes have pointer-chasing and allocation overhead. The deque column in the raw CSV measures a combined populate plus repeated addFirst/removeFirst workload, not a direct one-operation comparison.

### Recommendation and operating boundary
ArrayList is a sound default for playlists dominated by append, indexed jumps and iteration, with occasional edits. Stop recommending it when frequent front/middle insertions or removals dominate and shift costs become a bottleneck. For an “Up Next” queue that frequently adds at both ends and removes from the front, `ArrayDeque` is a better fit. It is not a general indexed list and does not offer efficient arbitrary middle insertion.

| Operation | ArrayList | LinkedList | ArrayDeque |
|---|---|---|---|
| Add at end | amortized O(1) | O(1) | amortized O(1) |
| Insert at front | O(n) shift | O(1) | amortized O(1) |
| Insert middle | O(n) shift/search | O(n) locate, O(1) link once found | no indexed middle operation; typically O(n) rebuild |
| Get k-th | O(1) | O(n) | no indexed access; O(n) traversal |
| Iterate | O(n) | O(n) | O(n) |
| Remove front | O(n) shift | O(1) | amortized O(1) |

ArrayList stores references in a contiguous backing array; LinkedList stores a node with item and previous/next references per element, so it has greater per-element overhead. ArrayDeque stores references in a circular array. A plain array with manual shifting has O(1) indexed access and O(n) insertion/removal except at the end when capacity permits; resizing may require O(n) copying.

## Q3 — hashCode–equals contract

The contract requires that if `a.equals(b)` is true, `a.hashCode() == b.hashCode()` must also be true. Equal objects may share a hash code, but unequal objects may also collide. HashSet first uses the hash to select a bucket and then uses equals among candidates. If equals is overridden but hashCode is inherited from Object, logically equal objects may go to different buckets and both remain in the set.

The supplied corrected `Student` uses immutable `regNo`, value-based `equals`, and `Objects.hash(regNo)`. The program also includes an intentionally broken class whose equals compares registration number while hashCode remains identity-based; this produced two entries for the same registration in the captured run. Hash collision patterns are implementation-dependent, so the failure is not guaranteed for every arbitrary sample. The corrected sample produces `Correct HashSet size: 2` for R1, R2, R1.

A field used by hashCode must not be mutated while the object is in a HashSet/HashMap. Mutation can leave it in the bucket selected by the old hash, so lookup/removal using its new hash may fail. Use immutable key fields or remove, mutate, and reinsert. A TreeSet with a comparator on registration number can deduplicate by comparator equality in O(log n); a HashMap keyed by registration number gives average O(1) put/lookup and stores one value per key. Both use O(n) space. TreeSet ordering must agree with the intended identity rule.

## Q4 — Pharmacy map selection

The benchmark creates medicines in three sizes and measures 100,000 lookups and report preparation. Raw results are in `results/q4.csv`.

| Medicines | HashMap lookup 100k ns | TreeMap lookup 100k ns | LinkedHashMap lookup 100k ns | HashMap sorted report ns | TreeMap report ns | LinkedHashMap report ns |
|---:|---:|---:|---:|---:|---:|---:|
| 1,000 | 7,052,160 | 15,936,702 | 5,396,054 | 917,624 | 373,162 | 401,576 |
| 10,000 | 1,671,219 | 11,252,131 | 1,299,208 | 3,988,623 | 942,301 | 755,479 |
| 50,000 | 2,047,336 | 16,348,424 | 2,542,392 | 12,016,513 | 5,181,490 | 4,145,699 |

HashMap put/get/remove are O(1) average, O(n) worst-case; iteration is O(n) plus capacity effects. TreeMap operations are O(log n), iteration is O(n) in key order. LinkedHashMap operations are O(1) average and iteration is O(n) in insertion order with linked-entry overhead. HashMap requires sorting keys (O(n log n)) for a code-order report; TreeMap provides it naturally. LinkedHashMap provides insertion order naturally; it needs sorting for code order. For this requirement, a LinkedHashMap can preserve the add-order report, while a separate TreeMap (or sorted view) supplies code order. A practical choice is to maintain both only if both reports are frequent enough to justify duplicate index memory; otherwise choose based on dominant access/report needs.

Define an acceptable single lookup target, for example under 1 ms at the expected inventory size on the deployment hardware, then validate under production-like load. The included batch timings are not a direct single-lookup latency measurement and must not be divided blindly into a service-level guarantee. Hashtable is generally not preferred in new code because it is a legacy synchronized map; use HashMap when external synchronization is unnecessary, or ConcurrentHashMap for concurrent access.

A sorted array with binarySearch provides O(log n) lookup and O(n) insertion due to shifting; producing code order is O(n) because it is already sorted. It can be compact and cache-friendly, but is less suitable for frequent updates. HashMap has average O(1) lookup but needs sorting for ordered output; TreeMap offers O(log n) lookup/update and continuously sorted iteration. All store O(n) entries; array storage has low per-entry overhead.

## Q5 — Generic leaderboard

`Leaderboard<T>` accepts a `Comparator<? super T>`, stores items, and returns a sorted copy so the original insertion list is unchanged. The comparator sorts points descending, goal difference descending, then name ascending. Output:

`[Eagles(9,6), Bisons(9,4), Panthers(9,4), Cobras(6,1)]`

Bisons is above Panthers because points and goal difference are equal, so the final alphabetical name comparison places “Bisons” before “Panthers”. The comparator chain is transitive because it applies a lexicographic sequence of valid total-order comparisons; it returns equality only when all three ranking fields match. It avoids subtraction (which can overflow) by using comparingInt and reversed. The extreme integer test is included.

Sorting the copy costs O(n log n) time and O(n) extra reference storage (plus sorting workspace). `Comparable<Team>` is appropriate if one natural ranking is intrinsic to Team. Comparator is more reusable when teams, players and colleges need different rankings. Stable sorting three times (least significant key first: name, goal difference, points) costs about three O(n log n) sorts and additional work; one comparator chain is clearer and needs one sort. `List<? extends T>` is useful when a method consumes a list of subtype instances, e.g. adding all `List<? extends T>` values into a `Leaderboard<T>`.

## Q6 — Emergency triage

A FIFO Queue alone serves arrival order and cannot prioritize severity. The PriorityQueue comparator orders smaller severity number first, then lower arrival counter first. Each admitted patient receives a monotonically increasing counter, so ties preserve FIFO arrival order. The captured program output is:

`Meena(S1) Kumar(S1) Lata(S2) Ravi(S3) John(S3) Asha(S5)`

Printing a PriorityQueue directly does not promise sorted iteration; repeatedly poll a copy (or poll the working queue) to display treatment order. Add and poll are O(log n); peek is O(1); storage is O(n). A sorted LinkedList takes O(n) to find insertion position and O(1) link once found; removing the head is O(1). Five FIFO queues provide O(1) enqueue/dequeue within a severity, and selecting the highest-priority non-empty queue takes at most five checks, O(1) because the number of levels is fixed. All approaches store O(n) patients.

Strict priority can starve severity-5 patients during continuous arrivals of critical cases. A fairness policy can track waiting time and raise an effective queue priority after a configured threshold, with a maximum-wait target and clinical governance. Do not let an automatic age rule override clinical reassessment. A PriorityQueue can readily handle 5,000 daily arrivals; the algorithm is not the main deployment risk. Real hospital use also needs concurrency control, persistence, audit logs, clinical validation, downtime handling and privacy/security controls.

## Q7 — Diagnose, redesign and validate

### A–D: Diagnosis, objective and prediction
The selected limitation is repeated removal from index zero of an ArrayList playlist. Each removal shifts all remaining references, so removing m items from a list of n costs O(mn) in a typical front-removal sequence (about O(n²) when m is proportional to n). Objective: make repeated front removals linear overall rather than quadratic. Redesign to `ArrayDeque`, using `removeFirst()`; its end operations are amortized O(1), so m removals are O(m), after O(n) initial population. Prediction: the advantage should grow with n for workloads dominated by front removals.

### E: Implementation and validation
`Q7/PlaylistRedesign.java` runs the same initial list sizes and removes one quarter from the front. It includes the cost of constructing a fresh copy/container in each trial.

| n | ArrayList front-removal workload ns | ArrayDeque front-removal workload ns |
|---:|---:|---:|
| 1,000 | 103,562 | 502,013 |
| 10,000 | 1,677,859 | 941,008 |
| 50,000 | 26,741,175 | 1,662,542 |

At n=1,000 the deque run is slower, plausibly because fixed setup/allocation overhead dominates. At 10,000 and 50,000 it is faster; at 50,000 the measured workload is about 16 times faster in this run. The benchmark is intentionally simple and should be repeated with warm-up/JMH for publication-quality results. The CSV is the raw record.

### F: Final defence
The objective is supported for large front-removal workloads, but ArrayDeque does not support indexed access or arbitrary middle insertion. ArrayList remains preferable for playlists requiring frequent `get(k)` and iteration with infrequent front edits. The redesign is therefore workload-specific, not a universal replacement.

## Final submission checklist

- Execute all programs on the submission machine and understand each output.
- Add genuine IDE/terminal screenshots if required; do not represent console text files as screenshots.
- Create and share the required GitHub repository, add the actual URL to this report and README, and commit each task progressively.
- The assignment brief requires raw measurements and progressive Git history. The ZIP contains source, measured local runs and report, but cannot create a GitHub repository or faculty access on the student's behalf.
