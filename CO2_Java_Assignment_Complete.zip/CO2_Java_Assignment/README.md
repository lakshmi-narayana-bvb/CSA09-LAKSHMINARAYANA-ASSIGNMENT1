# Programming in Java — Assignment 2 (CO2)

**Student:** Konnipati Lakshmi Narayana  
**Register Number:** 1925260030  
**Java used for local validation:** OpenJDK 21.0.12.1 (64-bit)  
**GitHub repository:** Add the URL after creating `CSA09-1925260030-Assignment2`.

## Contents

- `Q1/` String, StringBuilder and StringBuffer comparison
- `Q2/` ArrayList, LinkedList and ArrayDeque experiments
- `Q3/` HashSet, equals/hashCode contract and alternatives
- `Q4/` HashMap, TreeMap and LinkedHashMap comparison
- `Q5/` Generic Leaderboard and comparator chain
- `Q6/` Stable priority-based emergency triage queue
- `Q7/` Diagnose/redesign/validate playlist front-removal bottleneck
- `results/` Raw CSV and console output captured from local runs
- `Assignment_Report.md` Full written answers and complexity discussion
- `Assignment_Report.pdf` Printable report

## Compile and run

From the project root, compile each task independently:

```bash
javac Q1/*.java
java -cp Q1 TextBuilderBenchmark

javac Q2/*.java
java -cp Q2 ListBenchmark

javac Q3/*.java
java -cp Q3 Attendance

javac Q4/*.java
java -cp Q4 InventoryMaps

javac Q5/*.java
java -cp Q5 LeaderboardDemo

javac Q6/*.java
java -cp Q6 Triage

javac Q7/*.java
java -cp Q7 PlaylistRedesign
```

The benchmark output is also saved in `results/`. Re-run benchmarks on the submission computer and replace/append the raw results if the faculty requires evidence from that machine. Timings vary with CPU load, JVM warm-up, garbage collection and hardware. The measurements included here are actual runs in the stated OpenJDK 21 environment, not universal performance guarantees.

## Important submission checklist

1. Run every program yourself and understand the code/results before the viva.
2. Add genuine screenshots from your own terminal/IDE to the relevant task folders if required by faculty. Console captures are supplied as text; no fabricated screenshots are included.
3. Create the required GitHub repository `CSA09-1925260030-Assignment2`, add faculty access, and push each task with progressive commits (at least one commit per task).
4. Replace the GitHub placeholder in this README and in the report with the real repository URL.
5. The assignment sheet requires progressive Git history and execution evidence; a ZIP alone does not satisfy those requirements.
