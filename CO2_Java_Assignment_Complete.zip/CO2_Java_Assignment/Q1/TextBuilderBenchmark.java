import java.util.*;

public class TextBuilderBenchmark {
    static String buildPlus(List<String> fields) { String s = ""; for (String f : fields) s += f + "|"; return s; }
    static String buildBuilder(List<String> fields) { StringBuilder b = new StringBuilder(); for (String f : fields) b.append(f).append('|'); return b.toString(); }
    static String buildBuffer(List<String> fields) { StringBuffer b = new StringBuffer(); for (String f : fields) b.append(f).append('|'); return b.toString(); }
    static long time(Runnable r, int repeats) { long start=System.nanoTime(); for(int i=0;i<repeats;i++) r.run(); return (System.nanoTime()-start)/repeats; }
    public static void main(String[] args) {
        int[][] workloads={{6,1},{50,1000},{100,3000}};
        System.out.println("fields,tickets,plus_ns_per_ticket,builder_ns_per_ticket,buffer_ns_per_ticket,estimated_plus_intermediate_strings");
        for(int[] w:workloads){
            List<String> fields=new ArrayList<>(); for(int i=0;i<w[0];i++) fields.add("FIELD"+i+"_VALUE");
            int tickets=w[1];
            Runnable plus=()->{for(int i=0;i<tickets;i++) buildPlus(fields);};
            Runnable builder=()->{for(int i=0;i<tickets;i++) buildBuilder(fields);};
            Runnable buffer=()->{for(int i=0;i<tickets;i++) buildBuffer(fields);};
            plus.run(); builder.run(); buffer.run();
            long p=time(plus,3)/tickets, b=time(builder,5)/tickets, f=time(buffer,5)/tickets;
            System.out.printf(Locale.ROOT,"%d,%d,%d,%d,%d,%d%n",w[0],tickets,p,b,f,(long)tickets*(w[0]+1));
        }
        System.out.println("Shared log recommendation: synchronize access to one StringBuffer, or preferably use a dedicated logger/lock; per-ticket local StringBuilder is safe because it is not shared.");
    }
}
