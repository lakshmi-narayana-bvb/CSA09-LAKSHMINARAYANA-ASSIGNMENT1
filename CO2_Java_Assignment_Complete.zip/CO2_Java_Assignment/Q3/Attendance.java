import java.util.*;
class Student {
 private final String regNo,name;
 Student(String r,String n){regNo=r;name=n;}
 @Override public boolean equals(Object o){if(this==o)return true;if(!(o instanceof Student))return false;Student s=(Student)o;return Objects.equals(regNo,s.regNo);}
 // Correct contract: equal registration numbers always produce equal hash codes.
 @Override public int hashCode(){return Objects.hash(regNo);}
 @Override public String toString(){return regNo+" "+name;}
}
public class Attendance {
 public static void main(String[] args){
  Set<Student> good=new HashSet<>();good.add(new Student("R1","Arun"));good.add(new Student("R2","Divya"));good.add(new Student("R1","Arun"));System.out.println("Correct HashSet size: "+good.size());
  // Broken version is represented by BadStudent: identity hashCode conflicts with value equals.
  Set<BadStudent> bad=new HashSet<>();bad.add(new BadStudent("R1"));bad.add(new BadStudent("R1"));System.out.println("Broken-contract HashSet size (may expose duplicate): "+bad.size());
  Set<String> tree=new TreeSet<>(List.of("R1","R2","R1"));System.out.println("TreeSet keys: "+tree+", size="+tree.size());
  Map<String,String> byReg=new HashMap<>();byReg.put("R1","Arun");byReg.put("R2","Divya");System.out.println("HashMap de-duplication size: "+byReg.size());
 }
 static class BadStudent {final String reg;BadStudent(String r){reg=r;}public boolean equals(Object o){return o instanceof BadStudent && reg.equals(((BadStudent)o).reg);} /* intentionally no hashCode */}
}
