# Execution and evidence checklist

The assignment asks for screenshots of actual executed interactions. This package does not fabricate GUI screenshots. Run each GUI on a desktop and capture the following:

| Task | Evidence to capture | Suggested filename |
|---|---|---|
| 3 | Search screen at 520×360 | `Task03/evidence/size-small.png` |
| 3 | Search screen at 760×500 | `Task03/evidence/size-medium.png` |
| 3 | Search screen at 1100×700 | `Task03/evidence/size-large.png` |
| 4 | Several dots and updated click count | `Task04/evidence/draw-before-minimize.png` |
| 4 | Same dots after restore | `Task04/evidence/draw-after-restore.png` |
| 4 | Compiler diagnostic after changing method to `mouseclicked` and removing `@Override` (then restore correct code) | `Task04/evidence/override-diagnostic.png` |
| 5 | Valid conversion dialog | `Task05/evidence/valid-conversion.png` |
| 5 | Invalid amount dialog | `Task05/evidence/invalid-amount.png` |
| 6 | Successful registration | `Task06/evidence/normal-registration.png` |
| 6 | Invalid input feedback | `Task06/evidence/invalid-registration.png` |
| 6 | Duplicate registration feedback | `Task06/evidence/duplicate-registration.png` |
| 6 | Filtered table / page navigation | `Task06/evidence/filter-paging.png` |

For Task 4's compile-time check, `@Override` on the misspelled `mouseclicked` causes an error similar to:
`method does not override or implement a method from a supertype`.

Task 6 needs a running MySQL instance and Connector/J. A successful `javac` compile alone does not verify database connectivity.
