# Assignment 4 – Written Answers (CO4)

## Task 1 – GUI Design Review

### 1.1 Deficiencies
1. UI and business logic are coupled: payment rules and JDBC are inside the event handler, making them difficult to test independently.
2. `==` compares String references, not contents; the Pay branch may not run. Use `"Pay".equals(e.getActionCommand())`.
3. No validation: blank register number, nonnumeric, zero, negative, NaN or infinite amount can cause incorrect payments or exceptions.
4. JDBC runs on the event-dispatch thread (EDT); the window freezes while the database responds.
5. `Thread.sleep(3000)` blocks the EDT for three seconds; repainting and user interaction stop.
6. No meaningful feedback: `System.out.println` is invisible to the user; errors are not shown.
7. Receipt is not implemented; every non-Pay action clears fields, so Receipt behaves like Clear.
8. SQL is built by concatenating user input, allowing SQL injection and quoting errors. Use PreparedStatement.
9. Connection/statement are not closed; resources leak.
10. Window closing behavior is not handled and checked exceptions are not caught/reported.

### 1.2 Repair
`FeeWindow` gathers input and displays status. `FeeService` validates and records payment using a parameterised `PreparedStatement`. `SwingWorker` performs JDBC work away from the EDT. Each button has a clear responsibility; the window has a close handler.

### 1.3 Defence (under 100 words)
The redesigned window only handles presentation and user interaction, while `FeeService` owns validation and payment rules. The service can be tested without opening a window, and the UI can be changed without rewriting database logic. Parameterised SQL reduces security risk, try-with-resources closes JDBC resources, and `SwingWorker` keeps the interface responsive. Separate button actions also make each behavior easier to understand and maintain.

### Alternative listener design and complexity
With one listener and an if/else chain, dispatch checks up to k action commands: O(k) worst case. A dedicated listener per button routes directly to its handler after event dispatch: O(1) handler selection, with O(k) listener-object storage. A shared Swing `Action` is preferable when the same behavior is used by a button, menu item and keyboard shortcut.

## Task 2 – Hospital Outpatient Appointment Desk
See `Task02/DESIGN.md` for event table, component containment tree, SIMATS-style pseudocode and full event trace.

## Task 3 – Campus Library Search Screen
See `Task03/DESIGN.md` and `Task03/LibrarySearch.java`. BorderLayout allows the CENTER results area to grow; FlowLayout keeps the search and navigation controls at preferred sizes. Actual screenshots must be captured at the three specified sizes.

## Task 4 – Event-Handling Forensics

### 4.1 Defect
The callback is misspelled `mouseclicked`; the correct case-sensitive method is `mouseClicked`. Therefore the adapter's empty method is called and the counter does not change.

### 4.2 Failing interaction
Click to draw dots, minimise the window, then restore it. Dots drawn using `getGraphics()` disappear because the drawing was not stored and is not reconstructed during repaint.

### 4.3 Repair
Store each click as a `Point`, update the label, call `repaint()`, and iterate through the points in `paint(Graphics)` to draw 6×6 circles centred at the saved coordinates. Completed source is `Task04/DrawPad.java`.

### 4.4 Prevention
`@Override` instructs the compiler to verify that the method overrides an inherited method. With the spelling `mouseclicked`, compilation fails rather than silently defining an unrelated method.

### Alternative and complexity
Point list: O(n) drawing work per repaint and O(n) point storage. BufferedImage: repaint copies the image (proportional to pixel area) and uses O(width×height) pixel storage. Point storage is economical for sparse clicks; an image is useful for dense drawings and repeated repaints.

## Task 5 – Event-handling styles
Four implementations are in `Task05/ConverterStyles.java`; the completed lambda version is `Task05/ConverterLambda.java`. See `Task05/COMPARISON.md` for readability, field access, reuse, requirement changes and complexity. Assignment demonstration rates are fixed at 0.012 USD and 0.011 EUR per INR; they are not live exchange rates.

## Task 6 – Campus Event Registration
See `Task06/DESIGN.md` for all five stages, screen flow, architecture, pseudocode and 100,000-row comparison. The Swing/JDBC application is implemented in `Task06/`. `Task06/schema.sql` defines the database and unique constraint.
