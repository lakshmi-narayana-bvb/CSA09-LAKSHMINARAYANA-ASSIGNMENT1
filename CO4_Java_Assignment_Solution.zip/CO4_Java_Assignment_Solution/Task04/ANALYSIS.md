# Task 4 – Event-handling forensics

1. The method is written `mouseclicked`; Java listener method names are case-sensitive and the required method is `mouseClicked(MouseEvent)`. Therefore the adapter's default empty implementation runs. The label is never updated because the handler body is never invoked.
2. Click several locations, minimise the window, then restore it. The original one-shot `getGraphics()` drawing disappears because the drawing was not retained as application state and repainting reconstructs the window.
3. The repaired implementation stores each click as a `Point`, updates the label, calls `repaint()`, and draws every point in `paint(Graphics)`.
4. With `@Override`, misspelling the method causes a compiler error because no superclass/interface method is being overridden.

For n points, repainting the point-list design takes O(n) drawing operations and stores O(n) points. An off-screen `BufferedImage` is copied during repaint (roughly O(width × height) pixel copying, often optimised by the graphics pipeline); drawing a new dot updates the image. It uses O(width × height) pixel storage instead of O(n) point records. A point list is compact for sparse marks; a buffered image can make repeated repaints fast for dense drawings.
