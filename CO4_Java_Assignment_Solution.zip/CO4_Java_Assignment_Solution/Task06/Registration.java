package Task06;

public record Registration(long id, String studentId, String studentName, String eventName, String registeredAt) {}
