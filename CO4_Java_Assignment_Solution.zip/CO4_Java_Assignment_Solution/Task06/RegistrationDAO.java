package Task06;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RegistrationDAO {
    private final String url = System.getenv().getOrDefault("DB_URL", "jdbc:mysql://localhost:3306/campus_events");
    private final String user = System.getenv().getOrDefault("DB_USER", "root");
    private final String password = System.getenv().getOrDefault("DB_PASSWORD", "");

    private Connection connect() throws SQLException { return DriverManager.getConnection(url, user, password); }

    public void insert(String studentId, String studentName, String event) throws SQLException {
        String sql = "INSERT INTO registrations(student_id, student_name, event_name) VALUES (?, ?, ?)";
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, studentId); ps.setString(2, studentName); ps.setString(3, event);
            ps.executeUpdate();
        }
    }

    public List<Registration> page(String eventFilter, int limit, int offset) throws SQLException {
        String sql = "SELECT id, student_id, student_name, event_name, registered_at FROM registrations " +
                "WHERE (? = 'All' OR event_name = ?) ORDER BY id DESC LIMIT ? OFFSET ?";
        List<Registration> rows = new ArrayList<>();
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, eventFilter); ps.setString(2, eventFilter);
            ps.setInt(3, limit); ps.setInt(4, offset);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) rows.add(new Registration(rs.getLong("id"), rs.getString("student_id"),
                        rs.getString("student_name"), rs.getString("event_name"), rs.getString("registered_at")));
            }
        }
        return rows;
    }
}
