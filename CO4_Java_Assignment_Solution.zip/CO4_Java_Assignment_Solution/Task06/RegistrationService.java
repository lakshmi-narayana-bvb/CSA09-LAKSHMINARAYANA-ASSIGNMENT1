package Task06;

import java.sql.SQLException;
import java.util.List;

public class RegistrationService {
    private final RegistrationDAO dao;
    public RegistrationService(RegistrationDAO dao) { this.dao = dao; }

    public void register(String studentId, String studentName, String event) throws SQLException {
        if (studentId == null || !studentId.matches("[A-Za-z0-9-]{3,20}"))
            throw new IllegalArgumentException("Student ID must be 3–20 letters, digits or hyphens.");
        if (studentName == null || studentName.isBlank())
            throw new IllegalArgumentException("Student name is required.");
        if (event == null || event.isBlank() || event.equals("All"))
            throw new IllegalArgumentException("Choose a valid event.");
        dao.insert(studentId.trim(), studentName.trim(), event);
    }

    public List<Registration> getPage(String event, int page, int pageSize) throws SQLException {
        if (page < 0 || pageSize < 1) throw new IllegalArgumentException("Invalid page.");
        return dao.page(event, pageSize, page * pageSize);
    }
}
