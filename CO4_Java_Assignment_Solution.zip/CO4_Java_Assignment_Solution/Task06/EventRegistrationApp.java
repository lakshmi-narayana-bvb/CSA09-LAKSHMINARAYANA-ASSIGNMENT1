package Task06;

import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class EventRegistrationApp extends JFrame {
    private final RegistrationService service = new RegistrationService(new RegistrationDAO());
    private final JTextField studentId = new JTextField(12), studentName = new JTextField(16);
    private final JComboBox<String> event = new JComboBox<>(new String[]{"Cultural Fest", "Music Night", "Drama", "Dance"});
    private final JComboBox<String> filter = new JComboBox<>(new String[]{"All", "Cultural Fest", "Music Night", "Drama", "Dance"});
    private final DefaultTableModel model = new DefaultTableModel(new Object[]{"ID","Student ID","Student Name","Event","Registered At"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JLabel status = new JLabel("Ready");
    private int page = 0;
    private static final int PAGE_SIZE = 50;
    private boolean loading = false;

    public EventRegistrationApp() {
        super("Campus Event Registration");
        setLayout(new BorderLayout(8,8));
        JMenuBar bar = new JMenuBar();
        JMenu file = new JMenu("File");
        JMenuItem refresh = new JMenuItem("Refresh"), export = new JMenuItem("Export CSV"), exit = new JMenuItem("Exit");
        file.add(refresh); file.add(export); file.addSeparator(); file.add(exit); bar.add(file); setJMenuBar(bar);

        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT));
        form.setBorder(BorderFactory.createTitledBorder("Register for an event"));
        form.add(new JLabel("Student ID")); form.add(studentId);
        form.add(new JLabel("Name")); form.add(studentName);
        form.add(event);
        JButton register = new JButton("Register"); form.add(register);

        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.add(new JLabel("Filter event")); filterPanel.add(filter);
        JButton apply = new JButton("Apply"), previous = new JButton("Previous"), next = new JButton("Next");
        filterPanel.add(apply); filterPanel.add(previous); filterPanel.add(next);

        JPanel top = new JPanel(new BorderLayout()); top.add(form, BorderLayout.NORTH); top.add(filterPanel, BorderLayout.SOUTH);
        add(top, BorderLayout.NORTH); add(new JScrollPane(table), BorderLayout.CENTER); add(status, BorderLayout.SOUTH);

        register.addActionListener(e -> register());
        apply.addActionListener(e -> { page = 0; loadPage(); });
        refresh.addActionListener(e -> loadPage());
        previous.addActionListener(e -> { if (page > 0) { page--; loadPage(); } });
        next.addActionListener(e -> { page++; loadPage(); });
        export.addActionListener(e -> exportCsv());
        exit.addActionListener(e -> dispose());
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {
                if (loading) {
                    int answer = JOptionPane.showConfirmDialog(EventRegistrationApp.this,
                            "A database operation is in progress. Close anyway?", "Confirm close", JOptionPane.YES_NO_OPTION);
                    if (answer == JOptionPane.YES_OPTION) dispose();
                } else dispose();
            }
        });
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setSize(900, 560); setLocationRelativeTo(null);
        loadPage();
    }

    private void register() {
        try {
            // Fast local validation first; service repeats validation at the business boundary.
            if (studentId.getText().isBlank() || studentName.getText().isBlank())
                throw new IllegalArgumentException("Student ID and name are required.");
            setBusy(true, "Registering…");
            String id = studentId.getText(), name = studentName.getText(), selectedEvent = (String) event.getSelectedItem();
            new SwingWorker<Void,Void>() {
                @Override protected Void doInBackground() throws Exception { service.register(id, name, selectedEvent); return null; }
                @Override protected void done() {
                    try { get(); status.setText("Registration successful."); studentId.setText(""); studentName.setText(""); page = 0; loadPage(); }
                    catch (Exception ex) {
                        Throwable cause = ex.getCause();
                        String msg = cause == null ? ex.getMessage() : cause.getMessage();
                        if (msg != null && msg.toLowerCase().contains("duplicate")) msg = "This student is already registered for that event.";
                        status.setText("Registration failed: " + msg);
                        JOptionPane.showMessageDialog(EventRegistrationApp.this, status.getText(), "Registration error", JOptionPane.ERROR_MESSAGE);
                    } finally { setBusy(false, status.getText()); }
                }
            }.execute();
        } catch (IllegalArgumentException ex) { status.setText(ex.getMessage()); }
    }

    private void loadPage() {
        if (loading) return;
        setBusy(true, "Loading registrations…");
        String selected = (String) filter.getSelectedItem();
        new SwingWorker<List<Registration>,Void>() {
            @Override protected List<Registration> doInBackground() throws Exception { return service.getPage(selected, page, PAGE_SIZE); }
            @Override protected void done() {
                try {
                    List<Registration> rows = get(); model.setRowCount(0);
                    for (Registration r : rows) model.addRow(new Object[]{r.id(), r.studentId(), r.studentName(), r.eventName(), r.registeredAt()});
                    status.setText("Page " + (page + 1) + " — " + rows.size() + " registration(s).");
                } catch (Exception ex) { status.setText("Load failed: " + ex.getMessage()); }
                finally { setBusy(false, status.getText()); }
            }
        }.execute();
    }

    private void exportCsv() {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new java.io.File("registrations-page-" + (page + 1) + ".csv"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        try (java.io.PrintWriter out = new java.io.PrintWriter(chooser.getSelectedFile(), java.nio.charset.StandardCharsets.UTF_8)) {
            out.println("ID,Student ID,Student Name,Event,Registered At");
            for (int r = 0; r < model.getRowCount(); r++) {
                for (int c = 0; c < model.getColumnCount(); c++) {
                    if (c > 0) out.print(",");
                    String v = String.valueOf(model.getValueAt(r,c)).replace("\"", "\"\"");
                    out.print("\"" + v + "\"");
                }
                out.println();
            }
            status.setText("Current page exported.");
        } catch (Exception ex) { status.setText("Export failed: " + ex.getMessage()); }
    }

    private void setBusy(boolean busy, String message) {
        loading = busy; status.setText(message);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EventRegistrationApp().setVisible(true));
    }
}
