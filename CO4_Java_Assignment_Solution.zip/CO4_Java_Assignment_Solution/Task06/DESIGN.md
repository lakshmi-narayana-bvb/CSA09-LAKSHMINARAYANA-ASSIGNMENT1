# Task 6 – Campus Event Registration

## Stage 1 – Users, screens, data and testable requirements

**Users:** student registering; committee member viewing/filtering/exporting.  
**Screens:** registration form and registration list (combined desktop screen); validation/duplicate/error dialogs; CSV save dialog.  
**Data:** registration ID, student ID, student name, event name, registration timestamp.  
**Rules / acceptance criteria:**
1. A student ID must be 3–20 alphanumeric/hyphen characters.
2. Student name and event are mandatory.
3. The same student ID cannot register for the same event more than once.
4. The committee can filter by event and browse pages of 50 rows.
5. Database operations run in `SwingWorker`, not on the Swing EDT.
6. Errors and successful registrations produce visible status/dialog feedback.
7. The displayed page can be exported as CSV.

## Stage 2 – Screen and event flow

```text
Main JFrame
├── JMenuBar: File → Refresh | Export CSV | Exit
├── Registration JPanel: Student ID, Name, Event, Register
├── Filter JPanel: Event filter, Apply, Previous, Next
├── JTable inside JScrollPane
└── Status label

Register → validate → background INSERT → success/error dialog → refresh table
Filter → background SELECT with LIMIT/OFFSET → replace table rows
Export → save-file dialog → write displayed page to CSV
Exit → if database operation active, ask confirmation → dispose
```

## Stage 3 – Critical decisions

- UI performs immediate required-field checks; `RegistrationService` enforces business validation independently.
- `RegistrationDAO` uses `PreparedStatement`, not concatenated SQL.
- A database UNIQUE constraint on `(student_id, event_name)` is the authoritative race-safe duplicate check.
- `SwingWorker.doInBackground()` performs JDBC work. `done()` updates Swing controls on the EDT.
- Paging uses SQL `LIMIT` and `OFFSET` to avoid loading the entire table.

## Stage 4 – Class structure and pseudocode

```text
EventRegistrationApp (JFrame)
        |
        v
RegistrationService (validation + business rules)
        |
        v
RegistrationDAO (JDBC queries)
        |
        v
MySQL registrations table
Registration (data record)
```

Register pseudocode:
```text
ALGORITHM Register
INPUT studentId, studentName, event
BEGIN
    VALIDATE studentId format
    VALIDATE studentName is not blank
    VALIDATE event is selected
    START SwingWorker
        DAO inserts using PreparedStatement
        UNIQUE constraint rejects duplicate student/event pair
    ON completion
        IF insert succeeded THEN show success and refresh first page
        ELSE show clear validation/database/duplicate error
END
```

Filter pseudocode:
```text
ALGORITHM Filter
INPUT selectedEvent, pageNumber
BEGIN
    SET offset ← pageNumber × pageSize
    START SwingWorker
        rows ← DAO SELECT WHERE event matches (or All)
               ORDER BY id DESC LIMIT pageSize OFFSET offset
    ON completion
        CLEAR JTable model
        ADD each returned row to JTable model
        UPDATE status label
END
```

## Stage 5 – Implementation and tests

`EventRegistrationApp.java`, `RegistrationService.java`, `RegistrationDAO.java`,
`Registration.java` and `schema.sql` implement the layered application.

Test cases:
- Normal: new student ID + name + event → success and row appears.
- Invalid: blank name or malformed ID → clear validation message; no insert.
- Duplicate: repeat same student ID and event → unique constraint rejects it.
- Different event: same student ID for a different event → allowed.
- Filter: choose one event → only matching rows appear.
- Paging: navigate previous/next page; no more than 50 rows displayed.
- Responsiveness: observe that window remains interactive while query/insert is running.

### Alternative: load all 100,000 rows vs paged retrieval

Let N = 100,000 and P = 50 rows per page.

- Load-all: transfer and materialise O(N) rows; memory O(N × average row size); initial wait and JTable model construction can block the UI if not run in a worker. Even in a worker, large memory use and rendering overhead remain.
- Paging: each request transfers O(P) rows and holds O(P) visible row data in the client; database performs an indexed/ordered query and offset work. With deep offsets, the database may still scan/skip rows; keyset pagination can improve that further.
- The paged design gives faster first display and lower client memory. The current code runs each query in a `SwingWorker` so the EDT remains free.
