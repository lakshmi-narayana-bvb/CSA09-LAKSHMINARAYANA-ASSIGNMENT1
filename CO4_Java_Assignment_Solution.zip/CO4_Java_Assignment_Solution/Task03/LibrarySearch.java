package Task03;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class LibrarySearch extends JFrame {
    private final JTextField query = new JTextField(22);
    private final JComboBox<String> category = new JComboBox<>(new String[]{"All", "Book", "Journal", "Thesis"});
    private final DefaultTableModel model = new DefaultTableModel(new Object[]{"Title", "Author", "Category"}, 0);
    private final JTable results = new JTable(model);
    private final JLabel status = new JLabel("Ready");

    public LibrarySearch() {
        super("Campus Library Search");
        setLayout(new BorderLayout(8, 8));
        JLabel title = new JLabel("Campus Library", SwingConstants.CENTER);
        title.setFont(title.getFont().deriveFont(Font.BOLD, 20f));
        JPanel searchRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchRow.add(new JLabel("Search")); searchRow.add(query); searchRow.add(category);
        JButton search = new JButton("Search"); searchRow.add(search);
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton prev = new JButton("Prev"), next = new JButton("Next"), reserve = new JButton("Reserve");
        bottom.add(prev); bottom.add(next); bottom.add(reserve);
        JPanel north = new JPanel(new BorderLayout());
        north.add(title, BorderLayout.NORTH); north.add(searchRow, BorderLayout.SOUTH);
        add(north, BorderLayout.NORTH);
        add(new JScrollPane(results), BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);
        add(status, BorderLayout.PAGE_END); // status is kept visible in a dedicated footer below
        // Use a footer panel so status and navigation do not compete for BorderLayout.SOUTH.
        JPanel footer = new JPanel(new BorderLayout());
        footer.add(bottom, BorderLayout.CENTER); footer.add(status, BorderLayout.SOUTH);
        add(footer, BorderLayout.SOUTH);
        search.addActionListener(e -> {
            model.setRowCount(0);
            String term = query.getText().trim();
            if (term.isEmpty()) { status.setText("Enter a search term."); return; }
            model.addRow(new Object[]{term + " – sample result", "Library catalogue", category.getSelectedItem()});
            status.setText("1 result shown (demonstration data).");
        });
        prev.addActionListener(e -> status.setText("Previous page."));
        next.addActionListener(e -> status.setText("Next page."));
        reserve.addActionListener(e -> status.setText(results.getSelectedRow() < 0 ? "Select a result first." : "Reservation request recorded (demo)."));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(520, 360)); setSize(760, 500); setLocationRelativeTo(null);
    }
    public static void main(String[] args) { SwingUtilities.invokeLater(() -> new LibrarySearch().setVisible(true)); }
}
