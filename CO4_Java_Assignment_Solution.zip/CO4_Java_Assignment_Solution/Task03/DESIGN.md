# Task 3 – Layout design

- Main `JFrame`: `BorderLayout`; NORTH title/search area, CENTER results, SOUTH footer.
- North container: `BorderLayout`; title in NORTH and search row in SOUTH.
- Search row: `FlowLayout(LEFT)` because controls retain preferred sizes.
- Results: `JScrollPane` containing `JTable` in CENTER; BorderLayout gives it the remaining space as the frame grows.
- Footer: `BorderLayout`; navigation row in CENTER and status label in SOUTH. Navigation row uses FlowLayout.

Nested structure:
```text
JFrame BorderLayout
├── NORTH: JPanel BorderLayout
│   ├── NORTH: JLabel title
│   └── SOUTH: JPanel FlowLayout (query, category, Search)
├── CENTER: JScrollPane → JTable
└── SOUTH: JPanel BorderLayout
    ├── CENTER: JPanel FlowLayout (Prev, Next, Reserve)
    └── SOUTH: JLabel status
```

GridLayout would force equal-sized cells and is unsuitable for the variable-width search controls. CardLayout is useful for switching whole screens, not needed for this single screen. GridBagLayout offers precise constraints but is more verbose. Absolute positioning does not adapt when resized and can clip controls. Nested layout computation is approximately linear in the number of child components per layout pass; absolute positioning reduces manager work but transfers all resizing responsibility to the programmer. The nested design uses a few small panels; this modest space cost buys maintainability and responsive resizing.

Test at 520×360, 760×500 and 1100×700: the CENTER scroll pane should take the extra width/height while the title/search and footer controls remain at preferred sizes. Capture actual screenshots at these three sizes in `evidence/`; no screenshots are fabricated in this package.
