#!/bin/sh
set -eu
mkdir -p build
for task in Task01 Task03 Task04 Task05 Task06; do
  mkdir -p "build/$task"
  echo "Compiling $task"
  javac -d "build/$task" "$task"/*.java
done
echo "Compilation checks completed. Task06 requires MySQL Connector/J only at runtime."
