# Programming in Java – Assignment 4 (CO4): Event-Driven GUI Design

**Student:** Konnipati Lakshmi Narayana  
**Register Number:** 1925260030  
**Course:** Programming in Java (CSA09)  
**Java:** Java 17 or later (source uses standard AWT/Swing/JDBC APIs)

## Contents
- `Task01/` – diagnosis, FeeWindow/FeeService redesign, listener comparison
- `Task02/` – event model, component tree, pseudocode and event trace
- `Task03/` – resizable Swing library search screen
- `Task04/` – drawing-pad repair and completed TODO program
- `Task05/` – four event-handling styles and completed lambda converter
- `Task06/` – layered campus-event registration app, SQL schema and paged JDBC table
- `report/` – consolidated written answers and test/evidence checklist

## Compile and run
Open a terminal in the project root. Compile individual tasks:

```bash
javac -d out Task01/*.java
java -cp out Task01.FeeWindow
```

For Task 3:
```bash
javac -d out Task03/*.java
java -cp out Task03.LibrarySearch
```

For Task 4:
```bash
javac -d out Task04/*.java
java -cp out Task04.DrawPad
```

For Task 5:
```bash
javac -d out Task05/*.java
java -cp out Task05.ConverterLambda
```

For Task 6, install MySQL Server, create the database using `Task06/schema.sql`,
then set environment variables `DB_URL`, `DB_USER`, and `DB_PASSWORD`. Add
MySQL Connector/J to the runtime classpath, then compile and run:

```bash
javac -d out Task06/*.java
java -cp "out:mysql-connector-j.jar" Task06.EventRegistrationApp
```

A default URL is `jdbc:mysql://localhost:3306/campus_events`. The database
driver is a runtime dependency; the code imports only standard JDBC classes.

## Verification
Run `./run_checks.sh` (Linux/macOS) or compile the task directories individually.
GUI windows require a desktop session. Screenshots are not fabricated or embedded:
capture the running windows on a desktop and save them in the relevant task's
`evidence/` directory, using the evidence checklist in `report/TESTING.md`.

## Result summary
All six tasks have written answers and Java implementations where required.
Task 6 includes JDBC paging, background loading with `SwingWorker`, validation,
and a database uniqueness constraint to prevent duplicate student/event entries.
