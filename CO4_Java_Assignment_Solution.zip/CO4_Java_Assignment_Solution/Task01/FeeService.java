package Task01;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class FeeService {
    public record Payment(String registerNumber, double amount) {}

    public Payment validate(String regNo, String amountText) {
        if (regNo == null || regNo.isBlank()) throw new IllegalArgumentException("Enter register number.");
        final double amount;
        try { amount = Double.parseDouble(amountText); }
        catch (Exception ex) { throw new IllegalArgumentException("Enter a valid amount."); }
        if (!Double.isFinite(amount) || amount <= 0) throw new IllegalArgumentException("Amount must be greater than zero.");
        return new Payment(regNo.trim(), amount);
    }

    public void recordPayment(Connection connection, Payment payment) throws SQLException {
        String sql = "INSERT INTO fees(register_no, amount) VALUES (?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, payment.registerNumber());
            ps.setDouble(2, payment.amount());
            ps.executeUpdate();
        }
    }
}
