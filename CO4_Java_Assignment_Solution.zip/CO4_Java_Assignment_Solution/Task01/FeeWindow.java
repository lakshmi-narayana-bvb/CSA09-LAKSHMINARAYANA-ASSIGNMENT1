package Task01;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;

public class FeeWindow extends JFrame {
    private final JTextField regNo = new JTextField(14);
    private final JTextField amount = new JTextField(10);
    private final JLabel status = new JLabel("Enter details and choose Pay.");
    private final FeeService service = new FeeService();

    public FeeWindow() {
        super("Student Fee Payment");
        JPanel fields = new JPanel(new GridLayout(2, 2, 8, 8));
        fields.add(new JLabel("Register number")); fields.add(regNo);
        fields.add(new JLabel("Amount")); fields.add(amount);
        JButton pay = new JButton("Pay"), clear = new JButton("Clear"), receipt = new JButton("Receipt");
        JPanel actions = new JPanel(new FlowLayout());
        actions.add(pay); actions.add(clear); actions.add(receipt);
        add(fields, BorderLayout.NORTH); add(actions, BorderLayout.CENTER); add(status, BorderLayout.SOUTH);
        pay.addActionListener(e -> pay());
        clear.addActionListener(e -> { regNo.setText(""); amount.setText(""); status.setText("Cleared."); });
        receipt.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "Receipt is available after a successful payment. " + status.getText(), "Receipt", JOptionPane.INFORMATION_MESSAGE));
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { dispose(); }
        });
        pack(); setLocationRelativeTo(null);
    }

    private void pay() {
        final FeeService.Payment payment;
        try { payment = service.validate(regNo.getText(), amount.getText()); }
        catch (IllegalArgumentException ex) { status.setText(ex.getMessage()); return; }
        // Database I/O runs in SwingWorker, never on the Event Dispatch Thread.
        new SwingWorker<Void, Void>() {
            @Override protected Void doInBackground() throws Exception {
                String url = System.getenv().getOrDefault("DB_URL", "jdbc:mysql://localhost:3306/campus_events");
                try (Connection c = DriverManager.getConnection(url,
                        System.getenv().getOrDefault("DB_USER", "root"),
                        System.getenv().getOrDefault("DB_PASSWORD", ""))) {
                    service.recordPayment(c, payment);
                }
                return null;
            }
            @Override protected void done() {
                try { get(); status.setText("Payment recorded: " + payment.amount()); }
                catch (Exception ex) { status.setText("Payment failed: " + ex.getCause().getMessage()); }
            }
        }.execute();
    }

    public static void main(String[] args) { SwingUtilities.invokeLater(() -> new FeeWindow().setVisible(true)); }
}
