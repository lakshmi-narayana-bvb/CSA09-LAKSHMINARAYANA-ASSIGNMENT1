# Task 2 – Hospital Outpatient Appointment Desk

## 2.1 Event model

| Event source | Event object | Listener | Action |
|---|---|---|---|
| Department JComboBox | ItemEvent | ItemListener | Load doctors for selected department and reset doctor selection |
| Doctor JComboBox | ItemEvent | ItemListener | Refresh available slots for selected doctor |
| Slot JComboBox | ItemEvent | ItemListener | Store selected slot; enable Book when all required fields exist |
| Book JButton | ActionEvent | ActionListener | Validate patient ID and selections, then book |
| Window close | WindowEvent | WindowListener/WindowAdapter | If booking is active, ask before closing |
| Cancel/Reset JButton | ActionEvent | ActionListener | Clear patient and selections |

## 2.2 Containment tree

```text
JFrame AppointmentDesk (BorderLayout)
├── JPanel form (GridBagLayout)
│   ├── JLabel + JTextField patientId
│   ├── JLabel + JComboBox department
│   ├── JLabel + JComboBox doctor
│   └── JLabel + JComboBox timeSlot
├── JPanel actions (FlowLayout)
│   ├── JButton Book
│   └── JButton Reset
└── JLabel status (SOUTH)
```

## 2.3 Handler pseudocode (SIMATS-style)

```text
ALGORITHM RefreshDoctors
INPUT selectedDepartment
BEGIN
    doctorCombo.removeAllItems()
    slotCombo.removeAllItems()
    IF selectedDepartment is not null THEN
        doctors ← doctorMap.get(selectedDepartment)
        FOR EACH doctor IN doctors DO
            doctorCombo.addItem(doctor)
        END FOR
    END IF
    SET BookButton enabled only when all selections are available
END

ALGORITHM BookAppointment
INPUT patientId, department, doctor, slot
BEGIN
    IF patientId is empty THEN DISPLAY "Enter patient ID"; RETURN
    IF department OR doctor OR slot is not selected THEN
        DISPLAY "Select department, doctor and slot"; RETURN
    END IF
    SET bookingInProgress ← true
    TRY
        appointmentService.book(patientId, department, doctor, slot)
        DISPLAY confirmation number
    CATCH duplicate OR unavailable slot
        DISPLAY clear error message
    FINALLY
        SET bookingInProgress ← false
    END TRY
END
```

## 2.4 Event trace and applet comparison

1. `main` calls `SwingUtilities.invokeLater`.
2. The EDT constructs the frame and components; listeners are registered.
3. `setVisible(true)` displays the window.
4. A department selection creates an `ItemEvent`; the `ItemListener` refreshes doctors.
5. Book creates an `ActionEvent`; the `ActionListener` validates and starts the service.
6. On close, `windowClosing` runs; if a booking is active, a confirmation dialog is shown.
7. On approval, `dispose()` closes the window.

An applet uses container-managed lifecycle callbacks: `init()` once for setup, `start()` when active, `paint()` for drawing, `stop()` when inactive, and `destroy()` before removal. A standalone Swing frame instead starts from `main`, responds to events, and is closed/disposed explicitly.

## Alternative: database query on every department change

Let `d` be departments and `m` the total doctors, and `q` the database round-trip/query cost.

- Load once into `Map<String,List<Doctor>>`: initial load O(m), memory O(m+d); each department change O(1) map lookup plus O(r) to populate the r doctors shown.
- Query database on each change: each change incurs q + O(r) transfer/render work; database/network latency is repeated. Client memory can be O(r) rather than O(m), but database load and latency increase.
- For a small, stable doctor catalogue, caching is faster. For frequently changing or very large data, query with caching/refresh policy.
