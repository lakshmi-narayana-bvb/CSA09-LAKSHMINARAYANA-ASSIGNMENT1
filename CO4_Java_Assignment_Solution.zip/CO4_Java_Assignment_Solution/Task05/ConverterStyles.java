package Task05;

import java.awt.FlowLayout;
import java.awt.event.*;
import javax.swing.*;

public class ConverterStyles {
    private static double convertValue(String text, String currency) {
        double amount = Double.parseDouble(text.trim());
        if (!Double.isFinite(amount) || amount < 0) throw new NumberFormatException();
        return amount * (currency.equals("USD") ? 0.012 : 0.011);
    }

    // (a) Frame itself implements ActionListener.
    static class FrameListener extends JFrame implements ActionListener {
        JTextField amount = new JTextField(8); JComboBox<String> currency = new JComboBox<>(new String[]{"USD","EUR"});
        JLabel output = new JLabel(" "); JButton button = new JButton("Convert");
        FrameListener() {
            super("Frame implements ActionListener"); setLayout(new FlowLayout());
            add(amount); add(currency); add(button); add(output); button.addActionListener(this);
            setDefaultCloseOperation(EXIT_ON_CLOSE); pack();
        }
        @Override public void actionPerformed(ActionEvent e) { showResult(amount, currency, output, this); }
    }

    // (b) Named inner class; reusable and separately testable.
    static class NamedInner extends JFrame {
        JTextField amount = new JTextField(8); JComboBox<String> currency = new JComboBox<>(new String[]{"USD","EUR"});
        JLabel output = new JLabel(" "); JButton button = new JButton("Convert");
        NamedInner() {
            super("Named inner class"); setLayout(new FlowLayout());
            add(amount); add(currency); add(button); add(output); button.addActionListener(new ConvertHandler());
            setDefaultCloseOperation(EXIT_ON_CLOSE); pack();
        }
        private class ConvertHandler implements ActionListener {
            @Override public void actionPerformed(ActionEvent e) { showResult(amount, currency, output, NamedInner.this); }
        }
    }

    // (c) Anonymous inner class.
    static class Anonymous extends JFrame {
        JTextField amount = new JTextField(8); JComboBox<String> currency = new JComboBox<>(new String[]{"USD","EUR"});
        JLabel output = new JLabel(" "); JButton button = new JButton("Convert");
        Anonymous() {
            super("Anonymous inner class"); setLayout(new FlowLayout());
            add(amount); add(currency); add(button); add(output);
            button.addActionListener(new ActionListener() {
                @Override public void actionPerformed(ActionEvent e) { showResult(amount, currency, output, Anonymous.this); }
            });
            setDefaultCloseOperation(EXIT_ON_CLOSE); pack();
        }
    }

    // (d) Lambda expression.
    static class Lambda extends JFrame {
        JTextField amount = new JTextField(8); JComboBox<String> currency = new JComboBox<>(new String[]{"USD","EUR"});
        JLabel output = new JLabel(" "); JButton button = new JButton("Convert");
        Lambda() {
            super("Lambda"); setLayout(new FlowLayout());
            add(amount); add(currency); add(button); add(output);
            ActionListener action = e -> showResult(amount, currency, output, Lambda.this);
            button.addActionListener(action); amount.addActionListener(action);
            setDefaultCloseOperation(EXIT_ON_CLOSE); pack();
        }
    }

    private static void showResult(JTextField amount, JComboBox<String> currency, JLabel output, JFrame parent) {
        try {
            String c = (String) currency.getSelectedItem();
            output.setText(String.format("%.2f %s", convertValue(amount.getText(), c), c));
            JOptionPane.showMessageDialog(parent, output.getText(), "Result", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException ex) {
            output.setText("Invalid amount");
            JOptionPane.showMessageDialog(parent, "Invalid amount", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Lambda().setVisible(true));
    }
}
