# Task 5 – Event-handling style comparison

| Style | Readability | Access to frame fields | Reuse | Requirement change |
|---|---|---|---|---|
| Frame implements ActionListener | Simple for tiny windows, but mixes UI and handler | Direct | Low; frame is the listener | Add `actionPerformed` logic and register Enter separately |
| Named inner class | Clear named responsibility | Direct access to enclosing instance | Good; can attach same handler to multiple controls | Reuse handler for button and Enter; dialog change in one method |
| Anonymous inner class | Local and explicit, but verbose | Direct | Limited outside registration site | Add second registration or share an instance; change handler body |
| Lambda | Concise for one-method interfaces | Captures enclosing fields | Good when stored in a variable | Store one ActionListener and attach it to button and text field |

For a large application, prefer a named handler or a shared Swing `Action` (often with a method reference) because it centralises behavior, supports reuse across buttons/menu items/keyboard shortcuts, and is easier to test. A method reference such as `this::convert` is concise when the method signature matches the listener. A shared `Action` can also carry enabled state, label, icon and accelerator metadata.

Complexity: dispatch is O(1) for a direct listener callback after the event target is known. A chain of k action-command comparisons is O(k) worst case. k distinct listener objects require O(k) object references/storage; one shared listener can be registered with multiple event sources and uses O(1) listener object storage, aside from registrations maintained by components.

Task 5.2: Add `amount.addActionListener(sameHandler)` (or the same Action) to convert on Enter. Replace/update the output label and show a `JOptionPane` dialog in the shared conversion method. For frame-listener style, the frame receives both events; for named inner class, reuse one handler instance; anonymous style needs the listener saved in a variable if shared; lambda style stores one listener variable. This is a small one- to three-line registration change plus the shared result display update.
