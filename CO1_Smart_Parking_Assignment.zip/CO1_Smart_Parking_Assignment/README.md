# CO1 Java — Campus Smart-Parking Assignment

## Student details
- Name: [Enter your full name]
- Register number: [Enter your register number]
- GitHub repository: `CSA09-<RegisterNumber>-Assignment1`
- Java version: JDK 17+

## Contents
- `Assignment_Report.md` — answers for Tasks 1–12, pseudocode, UML, alternatives and complexity analyses.
- `src/parking/model` — vehicle, ticket and pass model classes.
- `src/parking/pricing` — pricing abstraction and implementation.
- `src/parking/service` — parking facility and active-ticket management.
- `src/parking/app` — executable system demonstration.
- `Task03_CompleteCode` — completed supplied slot allocation/release program.
- `Task08_CompleteCode` — completed supplied polymorphism/fee demo.
- `tests` — console output evidence from local execution.

## Compile and run
```bash
javac -d build $(find src -name "*.java")
java -cp build parking.app.ParkingDemo
```

Standalone completed code:
```bash
javac -d Task03_CompleteCode/build Task03_CompleteCode/ParkingFacility.java
java -cp Task03_CompleteCode/build ParkingFacility

javac -d Task08_CompleteCode/build Task08_CompleteCode/FeeDemo.java
java -cp Task08_CompleteCode/build FeeDemo
```

## Task results
| Task | Result |
|---|---|
| 1 | Identified domain objects, inputs/outputs, invariants and assumptions |
| 2 | Justified types and jagged array representation; explained precision |
| 3 | Added allocation/release pseudocode and completed `ParkingFacility` |
| 4 | Explained constructors, chaining, memory and alternatives |
| 5 | Implemented static ticket sequence and explained lifecycle |
| 6 | Implemented inheritance hierarchy and UML |
| 7 | Implemented overriding, equality and hash code |
| 8 | Completed `FeeDemo`; demonstrated runtime dispatch |
| 9 | Implemented abstract `Vehicle` and capability interfaces |
| 10 | Organized packages and encapsulated/validated state |
| 11 | Compiled and ran tests; documented expected and actual results |
| 12 | Added e-bike, delivery van, one-day pass and unequal floor capacities |

## Submission checklist
- [ ] Replace student detail placeholders.
- [ ] Create a GitHub repository named `CSA09-<RegisterNumber>-Assignment1`.
- [ ] Add faculty as collaborator if the repository is private.
- [ ] Commit each task progressively; do not make one final bulk commit.
- [ ] Capture genuine execution screenshots from your own computer and place them in the relevant task folders.
- [ ] Add the working GitHub URL to this README and the report.
- [ ] Review and understand the code so you can explain it during viva.

**Integrity note:** The console logs in `tests/` were produced by compiling and running the included programs in the preparation environment. No GitHub repository or screenshots are claimed to have been created.
