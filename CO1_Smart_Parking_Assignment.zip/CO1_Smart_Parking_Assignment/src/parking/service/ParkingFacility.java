package parking.service;

import parking.model.*;
import parking.pricing.*;
import java.time.LocalTime;
import java.util.*;

public class ParkingFacility {
    private final String[][] slots;
    private final Map<String, ParkingTicket> activeTickets = new HashMap<>();
    private final PricingRule pricingRule;
    private int occupancy;

    public ParkingFacility(int[] slotsPerFloor) { this(slotsPerFloor, new StandardPricingRule()); }
    public ParkingFacility(int[] slotsPerFloor, PricingRule pricingRule) {
        if (slotsPerFloor == null || slotsPerFloor.length == 0 || pricingRule == null)
            throw new IllegalArgumentException("Floors and pricing rule are required");
        this.slots = new String[slotsPerFloor.length][];
        for (int f = 0; f < slotsPerFloor.length; f++) {
            if (slotsPerFloor[f] < 0) throw new IllegalArgumentException("Negative slot count");
            this.slots[f] = new String[slotsPerFloor[f]];
        }
        this.pricingRule = pricingRule;
    }

    public synchronized ParkingTicket enter(Vehicle vehicle, UserPass pass) {
        if (vehicle == null) throw new IllegalArgumentException("Vehicle required");
        String key = vehicle.getRegNo();
        if (activeTickets.containsKey(key)) throw new IllegalArgumentException("Duplicate active registration: " + key);
        int[] position = allocate(key);
        if (position == null) throw new IllegalStateException("Parking facility is full");
        ParkingTicket ticket = new ParkingTicket(vehicle, position[0], position[1]);
        activeTickets.put(key, ticket);
        occupancy++;
        return ticket;
    }

    private int[] allocate(String vehicleNo) {
        for (int f = 0; f < slots.length; f++) {
            for (int s = 0; s < slots[f].length; s++) {
                if (slots[f][s] == null) {
                    slots[f][s] = vehicleNo;
                    return new int[]{f, s};
                }
            }
        }
        return null;
    }

    public synchronized double exit(String regNo, int parkedMinutes, LocalTime entryTime, UserPass pass) {
        if (regNo == null || parkedMinutes < 0 || entryTime == null)
            throw new IllegalArgumentException("Invalid exit data");
        ParkingTicket ticket = activeTickets.remove(regNo.trim().toUpperCase());
        if (ticket == null) throw new IllegalArgumentException("No active ticket for " + regNo);
        int f = ticket.getFloor(), s = ticket.getSlot();
        if (f < 0 || f >= slots.length || s < 0 || s >= slots[f].length || slots[f][s] == null)
            throw new IllegalStateException("Ticket/slot state is inconsistent");
        slots[f][s] = null;
        occupancy--;
        if (pass != null && pass.isValidForParking()) return 0.0;
        return pricingRule.fee(ticket.getVehicle(), parkedMinutes, entryTime);
    }

    public synchronized boolean release(int floor, int slot) {
        if (floor < 0 || floor >= slots.length || slot < 0 || slot >= slots[floor].length
                || slots[floor][slot] == null) return false;
        String reg = slots[floor][slot];
        slots[floor][slot] = null;
        activeTickets.remove(reg);
        occupancy--;
        return true;
    }

    public synchronized int getOccupancy() { return occupancy; }
    public int getFloorCount() { return slots.length; }
    public int getSlotCount(int floor) {
        if (floor < 0 || floor >= slots.length) throw new IndexOutOfBoundsException("Invalid floor");
        return slots[floor].length;
    }
}
