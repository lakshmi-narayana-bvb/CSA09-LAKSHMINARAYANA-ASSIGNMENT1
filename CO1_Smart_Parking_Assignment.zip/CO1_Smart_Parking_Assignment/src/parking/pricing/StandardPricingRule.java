package parking.pricing;
import parking.model.*;
import java.time.LocalTime;

public class StandardPricingRule implements PricingRule {
    @Override public double fee(Vehicle vehicle, int minutes, LocalTime entryTime) {
        if (vehicle == null || minutes < 0) throw new IllegalArgumentException("Invalid billing input");
        if (vehicle instanceof EBike) return vehicle.calculateFee(minutes);
        if (vehicle instanceof DeliveryVan) return ((DeliveryVan) vehicle).calculateFee(minutes, entryTime);
        return vehicle.calculateFee(minutes);
    }
}
