package parking.pricing;
import parking.model.Vehicle;
import java.time.LocalTime;

public interface PricingRule {
    double fee(Vehicle vehicle, int minutes, LocalTime entryTime);
}
