package parking.app;
import parking.model.*;
import parking.service.ParkingFacility;
import java.time.LocalTime;

public class ParkingDemo {
    public static void main(String[] args) {
        ParkingFacility facility = new ParkingFacility(new int[]{2, 1, 3, 2, 4});
        ParkingTicket t1 = facility.enter(new TwoWheeler("TN01AB1111"), null);
        ParkingTicket t2 = facility.enter(new Car("TN02CD2222"), null);
        ParkingTicket t3 = facility.enter(new ElectricCar("TN03EF3333"), null);
        ParkingTicket t4 = facility.enter(new EBike("TN04GH4444"), null);
        ParkingTicket t5 = facility.enter(new DeliveryVan("TN05JK5555"), null);
        System.out.println("Allocated tickets: " + t1.getTicketNo() + ", " + t2.getTicketNo()
                + ", " + t3.getTicketNo() + ", " + t4.getTicketNo() + ", " + t5.getTicketNo());
        double a = facility.exit("TN01AB1111", 60, LocalTime.of(8, 0), null);
        double b = facility.exit("TN02CD2222", 61, LocalTime.of(10, 0), null);
        double c = facility.exit("TN03EF3333", 120, LocalTime.of(10, 0), null);
        double d = facility.exit("TN04GH4444", 45, LocalTime.of(10, 0), null);
        double e = facility.exit("TN05JK5555", 60, LocalTime.of(10, 0), null);
        System.out.printf("Fees: %.2f, %.2f, %.2f, %.2f, %.2f%n", a, b, c, d, e);
        System.out.printf("Total collection: %.2f%n", a+b+c+d+e);
        System.out.println("Final occupancy: " + facility.getOccupancy());
        ParkingFacility passFacility = new ParkingFacility(new int[]{1});
        passFacility.enter(new Car("TN99ZZ9999"), null);
        double passFee = passFacility.exit("TN99ZZ9999", 180, LocalTime.of(11, 0),
                new OneDayPass(java.time.LocalDate.now()));
        System.out.println("Valid one-day pass fee: " + passFee);
    }
}
