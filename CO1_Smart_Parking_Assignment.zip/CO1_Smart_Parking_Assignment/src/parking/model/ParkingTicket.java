package parking.model;
import java.time.LocalDateTime;
import java.util.concurrent.atomic.AtomicLong;

public final class ParkingTicket {
    private static final AtomicLong NEXT_ID = new AtomicLong(1000);
    private final long ticketNo;
    private final Vehicle vehicle;
    private final int floor;
    private final int slot;
    private final LocalDateTime entryTime;

    public ParkingTicket(Vehicle vehicle, int floor, int slot) {
        this(NEXT_ID.incrementAndGet(), vehicle, floor, slot, LocalDateTime.now());
    }
    public ParkingTicket(long ticketNo, Vehicle vehicle, int floor, int slot, LocalDateTime entryTime) {
        if (ticketNo <= 0 || vehicle == null || floor < 0 || slot < 0 || entryTime == null)
            throw new IllegalArgumentException("Invalid ticket data");
        this.ticketNo = ticketNo;
        this.vehicle = vehicle;
        this.floor = floor;
        this.slot = slot;
        this.entryTime = entryTime;
    }
    public long getTicketNo() { return ticketNo; }
    public Vehicle getVehicle() { return vehicle; }
    public int getFloor() { return floor; }
    public int getSlot() { return slot; }
    public LocalDateTime getEntryTime() { return entryTime; }
}
