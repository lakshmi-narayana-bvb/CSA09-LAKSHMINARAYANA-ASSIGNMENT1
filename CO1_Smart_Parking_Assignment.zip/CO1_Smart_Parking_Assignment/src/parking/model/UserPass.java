package parking.model;
public interface UserPass {
    boolean isValidForParking();
}
