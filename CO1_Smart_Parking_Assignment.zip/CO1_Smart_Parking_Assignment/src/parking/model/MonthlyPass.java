package parking.model;
import java.time.LocalDate;
public class MonthlyPass implements UserPass {
    private final LocalDate validUntil;
    public MonthlyPass(LocalDate validUntil) {
        if (validUntil == null) throw new IllegalArgumentException("Expiry date required");
        this.validUntil = validUntil;
    }
    @Override public boolean isValidForParking() {
        return !LocalDate.now().isAfter(validUntil);
    }
}
