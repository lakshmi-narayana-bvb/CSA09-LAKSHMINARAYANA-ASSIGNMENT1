package parking.model;
import java.time.LocalDate;
public class OneDayPass implements UserPass {
    private final LocalDate validOn;
    public OneDayPass(LocalDate validOn) {
        if (validOn == null) throw new IllegalArgumentException("Pass date required");
        this.validOn = validOn;
    }
    @Override public boolean isValidForParking() { return LocalDate.now().equals(validOn); }
}
