package parking.model;

import java.util.Objects;

public abstract class Vehicle {
    private final String regNo;

    protected Vehicle(String regNo) {
        if (regNo == null || regNo.isBlank()) throw new IllegalArgumentException("Registration is required");
        this.regNo = regNo.trim().toUpperCase();
    }

    public final String getRegNo() { return regNo; }
    public abstract String getType();
    public abstract double ratePerHour();

    /** Every started hour is charged in full. */
    public double calculateFee(int minutes) {
        if (minutes < 0) throw new IllegalArgumentException("Duration cannot be negative");
        int hours = (minutes + 59) / 60;
        return hours * ratePerHour();
    }

    @Override public final boolean equals(Object o) {
        return o instanceof Vehicle && regNo.equals(((Vehicle) o).regNo);
    }
    @Override public final int hashCode() { return Objects.hash(regNo); }
    @Override public String toString() { return getType() + "[" + regNo + "]"; }
}
