package parking.model;
import java.time.LocalTime;
public class DeliveryVan extends Vehicle {
    private static final LocalTime WINDOW_START = LocalTime.of(9, 0);
    private static final LocalTime WINDOW_END = LocalTime.of(17, 0);
    public DeliveryVan(String regNo) { super(regNo); }
    @Override public String getType() { return "DeliveryVan"; }
    @Override public double ratePerHour() { return 60.0; } // double the car rate
    public double calculateFee(int minutes, LocalTime entryTime) {
        if (minutes < 0 || entryTime == null) throw new IllegalArgumentException("Invalid duration/time");
        int hours = (minutes + 59) / 60;
        boolean inPeakWindow = !entryTime.isBefore(WINDOW_START) && entryTime.isBefore(WINDOW_END);
        return hours * ratePerHour() * (inPeakWindow ? 1.0 : 0.5);
    }
}
