package parking.model;
public class Car extends Vehicle {
    public Car(String regNo) { super(regNo); }
    @Override public String getType() { return "Car"; }
    @Override public double ratePerHour() { return 30.0; }
}
