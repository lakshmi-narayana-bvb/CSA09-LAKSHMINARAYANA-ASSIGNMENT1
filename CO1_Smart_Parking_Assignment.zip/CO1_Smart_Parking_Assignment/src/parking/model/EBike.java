package parking.model;
public class EBike extends TwoWheeler {
    private static final double FLAT_PARKING_FEE = 15.0;
    public EBike(String regNo) { super(regNo); }
    @Override public String getType() { return "EBike"; }
    @Override public double calculateFee(int minutes) {
        if (minutes < 0) throw new IllegalArgumentException("Duration cannot be negative");
        return minutes == 0 ? 0.0 : FLAT_PARKING_FEE;
    }
}
