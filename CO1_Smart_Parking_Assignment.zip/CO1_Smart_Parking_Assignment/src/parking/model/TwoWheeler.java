package parking.model;
public class TwoWheeler extends Vehicle {
    public TwoWheeler(String regNo) { super(regNo); }
    @Override public String getType() { return "TwoWheeler"; }
    @Override public double ratePerHour() { return 10.0; }
}
