# Programming in Java — Assignment 1
## Campus Smart-Parking System (CO1)

**Student name:** ____________________  
**Register number:** ____________________  
**GitHub repository:** To be added after the repository is created  
**Java version used:** OpenJDK 17 (or compatible JDK 17+)  
**Status:** Tasks 1–12 answered; Java programs compiled and executed locally.

> The assignment sheet requires individual execution, progressive Git commits, output screenshots and a working GitHub repository. This package contains source code and captured console text outputs from local execution. It does not claim that a remote GitHub repository was created or that screenshots were taken. Add your details, create the required repository, take screenshots on your own machine, and commit each task separately before submission.

---

# Task 1 — Understand the Problem and Identify the Objects

### Inputs and outputs
Inputs: vehicle registration number and category; user category and pass validity; entry/exit time or parked duration; floor/slot configuration; charging energy in kWh where applicable.

Outputs: allocated floor and slot, unique ticket number, entry time, occupancy, parking fee, charging fee, and error messages for a full facility, duplicate registration or invalid operation.

### Candidate classes and responsibilities
| Candidate | Responsibility and reason |
|---|---|
| `Vehicle` | Common registration identity and fee contract; prevents duplicated vehicle state. |
| `TwoWheeler`, `Car`, `ElectricCar` | Represent different vehicle categories and their hourly rates/capabilities. |
| `Chargeable` | Optional EV charging capability, independent of the vehicle inheritance tree. |
| `ParkingTicket` | Stores unique ticket number, vehicle reference, position and entry timestamp. |
| `ParkingFacility` | Owns floors/slots, allocates/releases spaces and tracks active tickets/occupancy. |
| `UserPass`, `MonthlyPass`, `OneDayPass` | Represent pass validity without embedding user rules in vehicle classes. |
| `PricingRule` | Separates fee policy from parking-space management. |

Nouns such as vehicle, ticket, floor, slot and pass suggest classes. Verbs such as allocate, release, enter, exit and calculateFee suggest methods.

### Business rules
1. A slot contains at most one vehicle.
2. A vehicle registration can have at most one active ticket.
3. Ticket numbers are unique and are not reused during the process.
4. An allocation must use a valid free slot; a full facility rejects entry.
5. An exit must refer to an active ticket and release its slot exactly once.
6. Negative durations, invalid coordinates and invalid pass dates are rejected.
7. A valid eligible pass makes the parking charge zero; charging fees, if applicable, are a separate service charge.

### Assumptions
- Slots are assigned in floor-major order, choosing the first free slot.
- Registration numbers are normalized to uppercase.
- Rates are ₹10/hour for two-wheelers and ₹30/hour for cars; every started hour is rounded up.
- EV charging costs ₹12/kWh.
- An e-bike has a flat ₹15 parking charge for any positive stay.
- A delivery van is charged at twice the car rate (₹60/hour) during 09:00–17:00 and at the ordinary car rate outside that window. The assignment does not specify the outside-window rate; this is an explicit design assumption.
- The one-day pass is valid only on its stated calendar date.

### Alternative: objects vs parallel arrays
With objects, each `Vehicle` keeps its registration, type-specific behaviour and future attributes together. Searching a simple list is O(n); with a `HashMap<String, ParkingTicket>` keyed by registration, expected lookup is O(1). Parallel arrays (`regNo[]`, `type[]`, `entryTime[]`) also require O(n) search and use O(n) references per attribute array. Adding an attribute requires another parallel array and careful index synchronization. An object-based design adds a field to the class and constructor, reducing synchronization errors. Object references add per-object overhead, but improve cohesion and extensibility.

---

# Task 2 — Choose the Data Representation

| Field | Java type | Reason |
|---|---|---|
| Floor and slot index | `int` | Non-negative array indexes. |
| Registration number | `String` | Alphanumeric identifier. |
| Entry time | `LocalDateTime` | Date and time without manual string parsing. |
| Duration | `int` minutes | Whole-minute input and easy validation. |
| Fee | `double` for this teaching example | Supports fractional currency calculations; production billing should use `BigDecimal`. |
| Ticket number | `long` | Large monotonically increasing identifier. |
| Charging energy | `int` kWh | Matches the assignment's integer parameter. |

The facility uses a jagged `String[][]`: the first index is the floor and each row has the number of slots configured for that floor. This supports floors with unequal capacity. `null` means free; a registration string means occupied.

Input can be read with `Scanner` for an interactive console program. The supplied demonstration uses fixed test data so its output is repeatable.

### Casting and precision example
If 61 minutes is divided using integer arithmetic, `61 / 60` is `1`, which incorrectly bills one hour. Casting after division (`(double)(61 / 60)`) still gives `1.0`. The correct ceiling calculation is `(minutes + 59) / 60`, producing 2 hours for 61 minutes and 1 hour for exactly 60 minutes. For currency, `BigDecimal` with a defined rounding policy is safer than binary floating point.

### Alternative representations
A single one-dimensional array with `index = floor * slotsPerFloor + slot` assumes equal floor sizes. With unequal floors, prefix offsets are required, otherwise the index formula is wrong. A jagged array uses O(total slots) references and accesses a slot in O(1) once floor and slot are known. `ArrayList<String[]>` also supports unequal row lengths and has O(1) indexed access, with a small list-management overhead. Finding the first free slot by scanning is O(total slots).

---

# Task 3 — Design the Control Logic

### Allocation pseudocode
```text
ALGORITHM Allocate(vehicleNo)
    FOR each floor f from 0 to numberOfFloors - 1
        FOR each slot s from 0 to slotsOnFloor[f] - 1
            IF slot[f][s] is FREE THEN
                slot[f][s] <- vehicleNo
                RETURN (f, s)
            END IF
        END FOR
    END FOR
    RETURN NO_SLOT
END ALGORITHM
```

### Fee pseudocode
```text
ALGORITHM CalculateFee(vehicle, minutes, entryTime, pass)
    IF minutes < 0 THEN
        RETURN INVALID_INPUT
    END IF
    IF pass is valid for this parking date THEN
        RETURN 0
    END IF
    billableHours <- (minutes + 59) DIV 60
    IF vehicle is EBike THEN
        IF minutes = 0 THEN RETURN 0
        RETURN flatEBikeFee
    ELSE IF vehicle is DeliveryVan THEN
        IF entryTime is in [09:00, 17:00) THEN
            RETURN billableHours * 2 * carRate
        ELSE
            RETURN billableHours * carRate
        END IF
    ELSE
        RETURN billableHours * vehicle.ratePerHour
    END IF
END ALGORITHM
```

The nested loops stop immediately with `return` after finding a slot. `break` can stop one loop, while `continue` skips an occupied slot; direct `return` is clearest here. If no slot is free, allocation returns `null` and entry reports a full facility.

### Completed supplied `ParkingFacility` code
The completed standalone source is in `Task03_CompleteCode/ParkingFacility.java`. It validates floor and slot indexes, rejects already-free slots, and returns the first free coordinate.

**Observed output**
```text
[0, 0]
[0, 1]
[1, 0]
null
true false false
[0, 1]
```

### Alternative: free-slot stacks
A per-floor stack of free slot indexes makes allocation and release O(1) amortized, provided each release pushes the slot exactly once and allocation pops only from a non-empty stack. A free-count per floor helps skip full floors, but a count alone does not identify a free slot; scanning a selected floor can still take O(S). The scan design uses O(F×S) slot storage and O(F×S) worst-case allocation time. Stacks require O(F×S) additional indexes but make allocation/release O(1) amortized.

---

# Task 4 — Design Classes, Objects and Constructors

`Vehicle` and `ParkingTicket` use parameterized constructors because a valid registration and ticket data are essential. `ParkingFacility(int[])` delegates to `ParkingFacility(int[], PricingRule)` using `this(...)`, so default pricing is selected without duplicating initialization. `ElectricCar` calls `super(regNo)` to initialize inherited state.

A default constructor is appropriate only when a meaningful valid default exists. A copy constructor could create a ticket snapshot, but it must not copy a ticket number if ticket numbers must remain unique; a reissued ticket should receive a new identifier and preserve an audit link to the old ticket.

A local reference variable is stored in a stack frame; the object it refers to is allocated on the heap. Multiple references may refer to the same object. Java passes object references by value.

### Alternative construction approaches
- Default constructor plus setters permits temporarily incomplete objects and requires validation on every setter.
- Parameterized constructors validate all required state before the object is usable.
- Static factory methods can name creation modes (`createVisitorTicket`, for example), return subclasses or cached instances, and hide constructor details.

All approaches take O(1) time and O(1) object space per ticket; creating n tickets takes O(n) time and O(n) space. Constructor validation does not change asymptotic complexity but makes invalid states harder to create.

---

# Task 5 — Apply Static Members and the Object Life Cycle

`ParkingTicket.NEXT_ID` is static because the ticket sequence is shared by every ticket. `AtomicLong` also makes ID increments safe if ticket creation is concurrent. Occupancy is an instance field because each facility has its own count. Static utility methods are suitable for stateless conversions; a static initializer is unnecessary for this design.

When a vehicle exits, the facility removes its active-ticket map entry and clears the slot. If no other references point to the ticket or vehicle, those objects become eligible for garbage collection. Collection timing is controlled by the JVM, not by the program.

Methods receive `Vehicle`, `UserPass` and time values as parameters and return a `ParkingTicket`, fee or boolean result.

### Alternative: instance ticket counter
If each `ParkingFacility` owns an instance counter, two gates can both issue ticket 1, causing collisions if tickets are expected to be globally unique. If numbering is local to each gate, use a facility identifier plus local sequence (for example, `N-1`, `S-1`). A static counter uses O(1) counter storage for all k facilities; k instance counters use O(k). The n ticket objects themselves use O(n) space in either design.

---

# Task 6 — Design the Inheritance Hierarchy

The model uses hierarchical inheritance: `Vehicle` is the abstract superclass; `TwoWheeler` and `Car` are subclasses; `ElectricCar` extends `Car`. `DeliveryVan` extends `Vehicle`. `EBike` extends `TwoWheeler`. Shared registration state is inherited; subclasses supply type identity and rates. `ElectricCar` additionally implements `Chargeable`.

### UML class diagram
```mermaid
classDiagram
    class Vehicle {
      <<abstract>>
      -String regNo
      +getRegNo() String
      +getType()* String
      +ratePerHour()* double
      +calculateFee(minutes) double
    }
    class TwoWheeler
    class Car
    class ElectricCar
    class EBike
    class DeliveryVan
    class Chargeable {
      <<interface>>
      +chargingFee(kWh) double
    }
    Vehicle <|-- TwoWheeler
    Vehicle <|-- Car
    Car <|-- ElectricCar
    TwoWheeler <|-- EBike
    Vehicle <|-- DeliveryVan
    Chargeable <|.. ElectricCar
```

When an `ElectricCar` is created, execution is: memory allocation and field defaults → `Vehicle` constructor → `Car` constructor → `ElectricCar` constructor → remaining instance initialization. `super(regNo)` invokes the immediate superclass constructor; the chain reaches `Vehicle` first.

### Alternative: composition
A single `Vehicle` could contain a `VehicleType` strategy holding rate and policy. Adding a category then adds a new strategy object rather than a subclass. Both approaches compute a fee in O(1). Inheritance stores the common registration plus subclass state; composition adds a reference to a strategy per vehicle (O(1) additional space). Composition is more flexible when categories and pricing policies vary independently.

---

# Task 7 — Override and Specialise Behaviour

`ratePerHour()` is abstract in `Vehicle` and overridden in each concrete category. `getType()` is also overridden. `EBike` overrides `calculateFee()` for its flat fee. `DeliveryVan` provides a time-aware overload for the 09:00–17:00 rule.

`@Override` asks the compiler to verify that a method truly overrides a superclass method. The method name and parameter list must match; the return type must be the same or covariant; visibility cannot be reduced; checked exceptions cannot be broadened.

`final` is used for registration number, ticket identity fields and the static fee constants to prevent reassignment. `Vehicle.equals()` and `hashCode()` use normalized registration number, so two vehicle objects with the same registration compare equal. This is useful for registration identity, but a real system may also include issuing jurisdiction or tenant/campus ID to avoid collisions across regions.

### Alternative: switch on a type field
A single `calculateFee()` could switch on an enum (`TWO_WHEELER`, `CAR`, etc.). A switch is O(1) for a fixed enum in practical implementations; a chain of k comparisons can be O(k). Adding a type requires editing the central method and often its tests. Overriding keeps category-specific behaviour in each class, though adding a category still requires registering it with the pricing policy if pricing is centralized.

---

# Task 8 — Apply Polymorphism

Compile-time polymorphism is method overloading: methods can accept either minutes or a pair of time values. The compiler selects an overload from the declared argument types. Runtime polymorphism occurs when a `Vehicle` reference points to a `Car` or `TwoWheeler`; dynamic dispatch invokes the actual object's overridden method.

Example trace:
- Declared reference type: `Vehicle`
- Actual object type: `ElectricCar`
- Call: `v.calculateFee(130)`
- Runtime method: inherited `Vehicle.calculateFee`, which calls the dynamically dispatched `ratePerHour()` implementation from `Car`
- Charging capability is then invoked through the `Chargeable` interface.

A `Vehicle[]` can contain different subclasses through upcasting. This avoids repeated type-specific fee logic at the call site.

### Completed supplied `FeeDemo`
The completed standalone code is in `Task08_CompleteCode/FeeDemo.java`.

**Observed output**
```text
TwoWheeler TN01A1 -> Rs 30.0
Car TN02B2 -> Rs 90.0
ElectricCar TN03C3 -> Rs 210.0
true
```

The final line is true because equality is defined by registration number alone. That is reasonable if a registration uniquely identifies a vehicle irrespective of its current subtype; it would be incorrect if category or jurisdiction forms part of identity.

### Alternative: `instanceof` and casts
A chain of `instanceof` checks performs up to k tests for k categories (O(k)); virtual dispatch is conceptually one O(1) dispatch. The explicit-check version grows with every new type and centralizes knowledge of all subclasses, increasing maintenance and casting risk.

---

# Task 9 — Introduce Abstraction

`Vehicle` is abstract because a generic vehicle should not be instantiated without a concrete category/rate. `ratePerHour()` is abstract and each concrete subclass supplies it. `Chargeable` is an interface because charging is a capability that only some vehicles possess. A class may implement several interfaces, allowing capabilities without multiple class inheritance.

A default interface method could provide common charging-session validation; a static interface method could convert kWh units or validate a tariff. The current interface remains minimal.

### Alternative reversal
If `Vehicle` were an interface, it could not hold per-instance registration state through ordinary instance fields or define constructors. Implementing classes would duplicate that state or delegate it to a composed object. An interface can extend multiple interfaces, but a class still has only one superclass. Making `Chargeable` an abstract class would prevent `ElectricCar` from also extending `Car`, unless the hierarchy were redesigned. Method-call time is effectively O(1) in either design; per-object storage depends on where shared state is placed, not on interface dispatch itself.

---

# Task 10 — Enforce Encapsulation through Packages and Access Modifiers

### Package structure
- `parking.model`: vehicle hierarchy, ticket and pass types.
- `parking.pricing`: pricing abstraction and implementation.
- `parking.service`: facility operations and active-ticket registry.
- `parking.app`: executable demonstration.

Fields are private; constructors and public operations are exposed only where needed. `protected` is used for the vehicle constructor and abstract rate method so subclasses can initialize and specialize behaviour. Package-private access is appropriate for implementation details that should not be public API.

Getters expose read-only values. Constructors and methods reject blank registration numbers, negative durations, negative charging energy, invalid floors and invalid slots. The slot array is not exposed to callers.

Wrapper types such as `Integer` may be used in collections. Autoboxing converts between `int` and `Integer`; comparing two `Integer` references with `==` can compare object identity rather than numeric value. Use `.equals()` or unbox to `int`.

### Alternative: public fields
Public fields allow any caller to set negative duration, invalid indexes or duplicate registrations without a central validation point. Each caller would have to repeat the checks. A validation check itself is O(1) per update, but repeated in m call sites it creates O(m) duplicated maintenance locations. Encapsulation centralizes the O(1) validation in the class and protects invariants.

---

# Task 11 — Implement, Test and Defend the Design

The complete implementation is under `src/`. It includes a jagged floor array, a `HashMap` of active tickets, abstract vehicle types, a charging interface, passes and an injectable pricing rule.

### Hand-calculated demonstration
The demonstration uses:
- Two-wheeler: 60 minutes × ₹10/hour = ₹10.
- Car: 61 minutes rounds to 2 hours × ₹30 = ₹60.
- Electric car: 120 minutes × ₹30 = ₹60 parking fee. Charging is a separate capability and is demonstrated in the standalone `FeeDemo`.
- E-bike: positive stay = flat ₹15.
- Delivery van at 10:00: 60 minutes × ₹60/hour = ₹60.
- Total parking collection = ₹10 + ₹60 + ₹60 + ₹15 + ₹60 = **₹205**.

### Test table
| Test | Expected result | Actual result |
|---|---|---|
| Allocate first three slots in 2,1-floor setup | `[0,0]`, `[0,1]`, `[1,0]` | Passed; exact output matched |
| Allocate when full | `null` | Passed |
| Release occupied slot | `true` | Passed |
| Release same slot twice | `false` on second call | Passed |
| Release invalid floor | `false` | Passed |
| Allocate after release | Reuses `[0,1]` | Passed |
| FeeDemo two-wheeler, 130 min | ₹30 | ₹30.0 |
| FeeDemo car, 130 min | ₹90 | ₹90.0 |
| FeeDemo EV, 130 min + 10 kWh | ₹210 | ₹210.0 |
| Equal registration across Car/EV | `true` under current identity rule | `true` |
| Five-category scenario | Total ₹205; occupancy returns to zero | ₹205.00; 0 |
| Valid one-day pass | Parking fee ₹0 | ₹0.0 |

The three Java programs compiled successfully with JDK 17 and the captured output is in `tests/`. The test evidence is console output, not fabricated screenshots. Boundary behaviour includes exact-hour billing and 61-minute rounding. Invalid duration, duplicate active registration, invalid coordinates and unknown ticket are guarded by validation/exception paths in the full service.

### Evaluation
The design uses encapsulation (private state), inheritance (shared vehicle identity), polymorphism (overridden rates), abstraction (abstract `Vehicle`, `PricingRule`), and interface-based capabilities (`Chargeable`, `UserPass`). A limitation is that the sample `double` fee representation is not ideal for production financial calculations; `BigDecimal` and a persistent database transaction would be preferable. Also, the demo accepts duration as input rather than calculating it from the ticket timestamp, to keep tests deterministic.

### Alternative active-ticket structures
- Array: exit lookup is O(n), storage O(n).
- `ArrayList<ParkingTicket>`: lookup is O(n), removal after lookup may also shift O(n) elements; storage O(n).
- `HashMap<String, ParkingTicket>`: expected O(1) lookup/removal, worst-case can degrade with pathological hashing; storage O(n) with additional hash-table overhead.

---

# Task 12 — Re-evaluate and Adapt the Design Challenge

### A. Impact analysis
The new requirements add e-bikes, delivery vans and visitor one-day passes; extend capacity to five floors; and permit unequal slot counts. `EBike`, `DeliveryVan` and `OneDayPass` are added. `ParkingFacility` already uses a jagged array, so five floors with different capacities require only a different configuration such as `{20, 35, 50, 75, 100}`. Pricing logic is isolated behind `PricingRule`, though the sample `StandardPricingRule` must be updated to recognize new pricing categories.

### B. Evaluation of the original design
The original inheritance hierarchy supports new categories through subclasses, but a central pricing class may still need modification to select special policies. If pricing conditions are spread across vehicle subclasses, future rules can force changes to several classes. The revised approach centralizes policy selection in `PricingRule`, while vehicle classes expose category behaviour. Existing tested classes `Car` and `TwoWheeler` remain unchanged; the pricing policy is the principal extension point.

### C. Adaptation decision and revised structure
**Decision: MODIFY, not fully redesign.** Retain the abstract `Vehicle`, jagged floor array, ticket model and `HashMap` registry. Add:
- `EBike extends TwoWheeler` with a flat positive-stay fee.
- `DeliveryVan extends Vehicle` with a time-sensitive rate method.
- `OneDayPass implements UserPass`.
- `PricingRule` to isolate pricing policy.

The one-day pass returns zero parking fee when its date matches the exit date. The sample service accepts the pass at exit; a production system should bind the pass to the vehicle/ticket at entry and verify it at exit. This keeps the new rule auditable.

### D. Evidence-based defence
Only the new vehicle/pass classes and the pricing policy require extension for the two new categories; the tested `Car`, `TwoWheeler` and `ParkingTicket` classes remain unchanged. The test scenario confirms e-bike ₹15, delivery van ₹60 during the stated window, one-day pass ₹0, and the facility returns to zero occupancy after exits. A future category can be added as a subclass plus a pricing-policy case, or a separate pricing strategy. Trade-off: the policy selector is simple and readable for a small system but still requires modification for every new special tariff; a registry of composable strategies would improve open/closed extensibility for a larger deployment.

---

# Build and Run

From the project root:

```bash
javac -d build $(find src -name "*.java")
java -cp build parking.app.ParkingDemo
```

Run the two supplied standalone completed-code programs:

```bash
javac -d Task03_CompleteCode/build Task03_CompleteCode/ParkingFacility.java
java -cp Task03_CompleteCode/build ParkingFacility

javac -d Task08_CompleteCode/build Task08_CompleteCode/FeeDemo.java
java -cp Task08_CompleteCode/build FeeDemo
```

See `README.md` for task folders, commands and submission checklist.
