import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ATM {
    private static final double BALANCE = 5000.00;

    static double withdraw(String accountText, String amountText, double balance)
            throws IOException {
        int account;
        double amount;
        try {
            account = Integer.parseInt(accountText.trim());
            amount = Double.parseDouble(amountText.trim());
        } catch (NumberFormatException e) {
            throw new InputMismatchException("Account and amount must be numeric");
        }
        if (account <= 0) throw new IllegalArgumentException("Account number must be positive");
        if (amount <= 0) throw new IllegalArgumentException("Withdrawal must be positive");
        if (amount > balance) throw new IllegalArgumentException("Insufficient balance");
        // Simulated card-reader resource: absence is a checked I/O failure.
        Path reader = Path.of("Task01", "card-reader.dat");
        if (!Files.exists(reader)) throw new IOException("Card-reader file is missing: " + reader);
        return balance - amount;
    }

    public static void main(String[] args) {
        String account = args.length > 0 ? args[0] : "12345";
        String amount = args.length > 1 ? args[1] : "500";
        try {
            double remaining = withdraw(account, amount, BALANCE);
            System.out.printf("Withdrawal approved. Remaining balance: %.2f%n", remaining);
        } catch (InputMismatchException e) {
            System.out.println("Input error: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println("Transaction rejected: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("System error: " + e.getMessage());
        } finally {
            System.out.println("ATM session closed.");
        }
    }
}
