import java.io.IOException;

class ExamException extends Exception {
    ExamException(String message) { super(message); }
    ExamException(String message, Throwable cause) { super(message, cause); }
}
class ExamWindowClosedException extends ExamException {
    ExamWindowClosedException(String message) { super(message); }
}
class NotRegisteredException extends ExamException {
    NotRegisteredException(String message) { super(message); }
}
class SubmissionStorageException extends ExamException {
    SubmissionStorageException(String message, Throwable cause) { super(message, cause); }
}

class Storage {
    void save(String fileName, long sizeKb) throws SubmissionStorageException {
        try {
            if (sizeKb > 500) throw new IOException("Disk quota exceeded");
            System.out.println("Saved " + fileName);
        } catch (IOException e) {
            // TODO 1 completed: preserve the original IOException as the cause.
            throw new SubmissionStorageException("Could not store " + fileName, e);
        }
    }
}
class SubmissionService {
    private final Storage storage = new Storage();

    void submit(String file, long sizeKb, boolean registered, boolean examOpen)
            throws ExamException {
        if (!examOpen) throw new ExamWindowClosedException("Exam window has closed");
        if (!registered) throw new NotRegisteredException("Student is not registered");
        storage.save(file, sizeKb);
    }
}
public class StorageDemo {
    public static void main(String[] args) {
        SubmissionService service = new SubmissionService();
        try {
            service.submit("answer01.pdf", 120, true, true);
            service.submit("answer02.pdf", 800, true, true);
        } catch (ExamException e) {
            System.out.println("Error: " + e.getMessage());
            System.out.println("Cause: " +
                    (e.getCause() == null ? "No cause supplied" : e.getCause().getMessage()));
        }
    }
}
