# Programming in Java – Assignment 3 (CO3)

**Student:** Konnipati Lakshmi Narayana  
**Register Number:** 1925260030  
**Course:** Programming in Java – CO3  
**Java target:** Java 8+ (recommended: JDK 17 or later)

## Contents
- `Task01/` – ATM exceptions and validation
- `Task02/` – user-defined exceptions, propagation and chaining
- `Task03/` – file resource safety: manual close and try-with-resources
- `Task04/` – Thread, Runnable and thread life cycle
- `Task05/` – race conditions and synchronized seat booking
- `Task06/` – deadlock prevention and bounded producer-consumer buffer
- `Task07/` – fault-tolerant result processor using ExecutorService, Callable and Future
- `REPORT.md` – written answers, test plans, diagrams, complexity analysis and contribution record

## Compile and run
Open a terminal in the assignment root. Each task is independent.

```bash
javac Task01/ATM.java
java -cp Task01 ATM

javac Task02/StorageDemo.java
java -cp Task02 StorageDemo

javac Task03/SalesReport.java
java -cp Task03 SalesReport

javac Task04/ThreadStations.java
java -cp Task04 ThreadStations

javac Task05/SeatBooking.java
java -cp Task05 SeatBooking

javac Task06/TokenCounter.java
java -cp Task06 TokenCounter

javac Task07/ResultProcessor.java
java -cp Task07 ResultProcessor
```

For Task 7, sample input files are in `Task07/input/`. The program accepts an optional input-directory argument:
`java -cp Task07 ResultProcessor Task07/input`

## Notes on evidence
The source programs are provided and were compiled/executed where a Java compiler is available. Thread completion order and elapsed-time measurements vary by machine and run. Do not present illustrative timing values as universal results. Replace the contribution record with the actual names and work performed by both partners, and add genuine screenshots / GitHub URL before submission.

## GitHub submission checklist
1. Create `CSA09-1925260030-Assignment3`.
2. Add the complete folder contents.
3. Commit each task separately as it is completed and tested.
4. Add the faculty member as collaborator if the repository is private.
5. Paste the working repository URL on the cover page and in the submission form.
