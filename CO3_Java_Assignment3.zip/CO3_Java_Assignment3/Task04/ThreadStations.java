public class ThreadStations {
    static class ExtendedStation extends Thread {
        private final int station, scripts;
        ExtendedStation(int station, int scripts) {
            super("Station-" + station); this.station = station; this.scripts = scripts;
        }
        public void run() { process(station, scripts); }
    }
    static class RunnableStation implements Runnable {
        private final int station, scripts;
        RunnableStation(int station, int scripts) { this.station = station; this.scripts = scripts; }
        public void run() { process(station, scripts); }
    }
    static void process(int station, int scripts) {
        try {
            Thread.sleep(100L + station * 40L); // illustrative processing delay
            System.out.println("Station " + station + " scanned " + scripts + " scripts.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("Station " + station + " interrupted.");
        }
    }
    public static void main(String[] args) throws InterruptedException {
        Thread[] stations = {
            new ExtendedStation(1, 25),
            new Thread(new RunnableStation(2, 30), "Station-2"),
            new ExtendedStation(3, 20),
            new Thread(new RunnableStation(4, 25), "Station-4")
        };
        for (Thread t : stations) t.start();
        for (Thread t : stations) System.out.println(t.getName() + " alive before join: " + t.isAlive());
        for (Thread t : stations) t.join();
        System.out.println("All stations finished. Total scripts scanned: 100");
    }
}
