# Build and execution log

Generated in the current environment.

## Task01 compilation: PASS
## Task02 compilation: PASS
## Task03 compilation: PASS
## Task04 compilation: PASS
## Task05 compilation: PASS
## Task06 compilation: PASS
## Task07 compilation: PASS
## Task01 execution: PASS
```text
System error: Card-reader file is missing: Task01/card-reader.dat
ATM session closed.
```
## Task02 execution: PASS
```text
Saved answer01.pdf
Error: Could not store answer02.pdf
Cause: Disk quota exceeded
```
## Task04 execution: PASS
```text
Station-1 alive before join: true
Station-2 alive before join: true
Station-3 alive before join: true
Station-4 alive before join: true
Station 1 scanned 25 scripts.
Station 2 scanned 30 scripts.
Station 3 scanned 20 scripts.
Station 4 scanned 25 scripts.
All stations finished. Total scripts scanned: 100
```
## Task05 execution: PASS
```text
Seats sold: 10
Successful booking calls: 10
```
## Task06 execution: PASS
```text
Sum of tokens collected: 210 (expected 210)
Final buffer size: 0
```
## Task07 execution: PASS
```text
Pool size: 4
missing-student.txt | FAILED: NoSuchFileException: Task07/input/missing-student.txt
student01.txt | SUCCESS score=88
student02.txt | SUCCESS score=73
student03.txt | FAILED: NumberFormatException: For input string: "not-a-number"
student04.txt | FAILED: IllegalArgumentException: Score must be 0..100
student05.txt | SUCCESS score=91
Summary: total=6, success=3, failed=3
Elapsed ms: 36
```
## Task03 execution: PASS
```text
Reading: Task03/input/store1.txt
Reading: Task03/input/store2.txt
Both reports generated. Expected total sales: 700
```
