# Assignment 3 – CO3 Written Report

**Student:** Konnipati Lakshmi Narayana  
**Register Number:** 1925260030  
**GitHub repository:** To be added after creating the repository  
**Partner / Student B:** Enter the actual partner's name before submission.

> The assignment requires both partners to execute every task individually. The report below supplies a complete technical solution and analysis. Run the programs on the submission computer, capture genuine output screenshots, record the actual Java version and timings, and complete the contribution record truthfully.

---

## Q1 – Handling Failure in a Bank ATM Simulation

### Relevant `Throwable` hierarchy

```text
Throwable
├── Error (for example, OutOfMemoryError) – serious JVM/resource failure
└── Exception
    ├── IOException – checked
    └── RuntimeException – unchecked
        ├── IllegalArgumentException – unchecked
        └── InputMismatchException – unchecked
```

### Failure analysis

| Failure point | Exception / failure | Classification | Handling |
|---|---|---|---|
| Account or amount contains letters | NumberFormatException converted to InputMismatchException | Unchecked | InputMismatchException catch |
| Account number is zero/negative | IllegalArgumentException | Unchecked | IllegalArgumentException catch |
| Amount is zero/negative | IllegalArgumentException | Unchecked | IllegalArgumentException catch |
| Amount exceeds available balance | IllegalArgumentException | Unchecked | IllegalArgumentException catch |
| Card-reader file missing/unreadable | IOException | Checked | IOException catch |
| JVM cannot allocate required memory | OutOfMemoryError | Error | Not normally caught by application |

### Catch order and `finally`
Specific exception types are caught before broader types so that each failure can receive an appropriate message. A broad `Exception` catch placed first would make later narrower catches unreachable and the compiler reports an error. The `finally` block runs after normal completion or exception handling (except abnormal JVM termination) and prints the session-closed message. It is suitable for cleanup, not for hiding failures.

### Student B – test plan and trace
| Test | Account | Amount | Expected path | Finally |
|---|---:|---:|---|---|
| Valid withdrawal | 12345 | 500 | Approved | Yes |
| Non-numeric amount | 12345 | abc | InputMismatchException | Yes |
| Invalid account | -1 | 100 | IllegalArgumentException | Yes |
| Negative amount | 12345 | -20 | IllegalArgumentException | Yes |
| Over balance | 12345 | 6000 | Insufficient balance | Yes |
| Missing reader file | 12345 | 100 | IOException | Yes |

A representative uncaught stack trace (if the relevant catch is removed) has the exception class and message on its first line, followed by stack frames from the method where it was thrown toward the caller. Each `at Class.method(File.java:line)` frame identifies the call path and source location. Exact line numbers depend on the local compiler/source file.

### Joint question
Catching only `Exception` can be acceptable at a top-level application boundary to log an unexpected failure and prevent an abrupt user-facing crash. It is not ideal around each operation: it loses precise recovery decisions, may hide programming defects, and can produce vague messages. `Error` is not caught by `Exception`.

### Alternative: validation and error codes
The program can validate with `Scanner.hasNextInt()` / `hasNextDouble()`, range checks, and return a status such as `0` success, `-1` invalid input, `-2` insufficient funds, `-3` device failure. This avoids exceptions for expected invalid input but requires callers to interpret codes and can become less readable when many checks are nested. Validation is O(1) time and O(1) extra space for a fixed number of fields. Normal error-code returns are O(1). Exception creation/throwing is typically more expensive because a stack trace is captured; stack-trace work is proportional to stack depth D, with O(D) trace storage. These costs are implementation-dependent.

---

## Q2 – User-Defined Exceptions and Propagation

### Exception hierarchy

```text
Exception
└── ExamException (checked)
    ├── ExamWindowClosedException
    ├── NotRegisteredException
    └── SubmissionStorageException
         └── cause: IOException
```

The business-rule failures are checked because submission cannot continue and callers should handle them explicitly. `SubmissionStorageException` is checked because storage failure is an expected operational condition requiring a meaningful response or retry decision.

### Propagation path
`Storage.save()` catches low-level `IOException`, wraps it as `SubmissionStorageException` while preserving the cause, and declares it with `throws`. `SubmissionService.submit()` propagates the `ExamException` family. The controller (`main`) catches `ExamException` and displays a safe message. The original cause remains accessible through `getCause()`.

### Complete Code result
```text
Saved answer01.pdf
Error: Could not store answer02.pdf
Cause: Disk quota exceeded
```
If the cause is not passed to the constructor, `getCause()` is `null`; the demonstration prints `Cause: No cause supplied`. The low-level reason and original stack trace relationship are lost.

### Scenarios and chaining
- Closed exam window → `ExamWindowClosedException`.
- Student not registered → `NotRegisteredException`.
- File larger than 500 KB / quota exceeded → `SubmissionStorageException` caused by `IOException`.

Chaining preserves abstraction: the UI sees a domain-specific storage failure rather than an implementation-specific file-system detail, while logs and diagnostics retain the original cause. Re-throwing without the cause loses the original exception type, message, and original stack trace.

### Checked versus unchecked alternative
If the custom exceptions extend `RuntimeException`, methods need not declare them in `throws` clauses and callers are not forced by the compiler to catch or declare them. Runtime behavior still propagates normally. This makes signatures shorter but weakens compile-time visibility of expected business failures.

Stack trace capture and storage are O(D) in stack depth D. A chained exception adds a reference to its cause and retains the cause object and its trace, so memory is approximately the sum of both exception objects and their trace data.

---

## Q3 – Resource Safety, Debugging and Robust Code

The `SalesReport` program demonstrates both manual closing and try-with-resources. Each store file is opened, read, and closed. The report writer is also closed.

### Resource and correctness analysis
- Resources: output `BufferedWriter`, one `BufferedReader` per input store file.
- A manual implementation can leak a reader if an exception occurs before its `close()` statement. A correct `finally` must close every resource that was successfully opened, even when an earlier close fails.
- Try-with-resources closes resources automatically in reverse order of declaration, including when the body throws.
- If the body throws and `close()` also throws, the body exception remains primary and the close exception is attached as a suppressed exception. Call `getSuppressed()` to inspect it.

### Failure experiment
Use a store file containing a non-numeric value (for example `oops`) after one valid line. The parsing operation fails part-way. The safe version closes the current reader, writer, and previously scoped resources. The manual example's cleanup list closes readers still registered in `opened`; this illustrates why every successful open must be tracked and closed.

### Joint decision
Try-with-resources does not validate business data, guarantee atomic report replacement, prevent disk-full errors, or make partially written output complete. A robust production design should write to a temporary file, validate all inputs, then atomically move the completed report into place where supported.

### Complexity
For f files containing a total of N lines, processing is O(N) time and O(1) application data beyond buffers (assuming streaming). With one input reader at a time plus one writer, try-with-resources uses O(1) open handles. A correctly implemented manual finally also uses O(1) handles. A flawed implementation that opens all f readers before closing them can hold O(f) handles. No closing can also grow to O(f), eventually exhausting the process limit.

---

## Q4 – Thread Creation and Life Cycle

The program uses both `extends Thread` and `implements Runnable`.

### Comparison
- Extending `Thread` is direct but uses the single-inheritance slot and couples task logic to thread management.
- Implementing `Runnable` separates the task from the execution mechanism and allows the class to extend another class or be submitted to an executor. Prefer `Runnable` for most task definitions.

### Life-cycle diagram

```text
NEW --start()--> RUNNABLE
RUNNABLE --scheduler selects--> RUNNING (conceptual execution)
RUNNING --sleep()/wait()/blocking I/O--> TIMED_WAITING/WAITING/BLOCKED
WAITING/BLOCKED --condition/timeout/lock available--> RUNNABLE
RUNNING --run() completes--> TERMINATED
```
Java's `Thread.State` combines runnable and running into `RUNNABLE`; “running” is a conceptual CPU-execution state, not a separate enum value. `join()` blocks the calling thread until the target terminates. `isAlive()` reports whether a started thread has not yet terminated.

Calling `run()` directly is an ordinary method call on the current thread; only `start()` asks the JVM to create/schedule a separate thread. `join()` on every station ensures the final total is printed after all stations finish.

### Behavioural experiments
Run the program ten times and record the finish order from each actual run. The order can vary because scheduling, processor load, and timing vary. Priorities are scheduling hints, not guarantees. A daemon thread does not keep the JVM alive; if only daemon threads remain after `main` ends, the JVM may exit before its work finishes. Do not use daemon threads for work that must complete.

### Executor alternative and complexity
A fixed pool reuses p worker threads and accepts station tasks through `ExecutorService`. For n equal-sized independent script jobs, idealized work per worker is about n/p jobs; actual time also includes scheduling and I/O overhead. Creating four dedicated threads uses O(4 × stack-size) thread-stack memory. A fixed pool uses O(p × stack-size), with p chosen according to workload and available processors.

---

## Q5 – Race Conditions in Cinema Seat Booking

The `book()` method is synchronized, making the check-then-set sequence atomic with respect to other calls using the same `SeatBooking` object. The expected output is:

```text
Seats sold: 10
Successful booking calls: 10
```

### Race explanation
Without synchronization, two threads may both read `booked[seat] == false` before either writes `true`. Both then proceed to book the same seat and increment the counter. The critical section is the check of the seat state, assignment to `true`, and increment of `bookingsMade`.

A synchronized instance method locks `this` for the entire method. A synchronized block such as `synchronized (booked) { ... }` can lock only the critical section, provided every access follows the same lock discipline. Static synchronization locks the `Class` object and is useful only if booking state is static/shared across all instances; for per-screen state, use an instance-specific lock.

### Alternative designs
- `AtomicBoolean[]`: each seat has an atomic flag; `compareAndSet(false, true)` claims it once. O(1) expected time per attempt, O(s) flags for s seats.
- `ReentrantLock`: lock around check/update; O(1) work plus contention/lock wait, O(1) lock object.
- `ConcurrentHashMap.putIfAbsent`: map seat IDs to booking markers; average O(1) insertion/claim, O(s) map entries and overhead.

For 20 screens, use one lock/state object per screen or per seat to avoid unrelated screens blocking each other. Atomic per-seat claims offer fine-grained concurrency; a simple synchronized method is easier to verify and adequate when booking work is short.

---

## Q6 – Deadlock and Inter-Thread Communication

### Producer-consumer
The fixed-size circular buffer has capacity 5. `put()` waits while full; `take()` waits while empty. Both operations are synchronized, so the condition check and state update occur under the same monitor. `wait()` releases the monitor while waiting and reacquires it before returning. `sleep()` pauses without releasing any monitor held by the thread.

The condition must be checked in a `while` loop because wakeups can be spurious and another thread may consume/change the condition before the awakened thread reacquires the lock. `notifyAll()` wakes all waiters so the appropriate producer/consumer can re-check its condition. `notify()` may wake a thread that cannot proceed while a suitable waiter remains asleep, depending on the design.

The tokens 1 through 20 sum to 210; therefore the expected final output is:
```text
Sum of tokens collected: 210 (expected 210)
Final buffer size: 0
```
Changing `while` to `if` is unsafe because a thread may continue after a spurious or no-longer-valid wakeup, potentially causing incorrect state or array access.

### Deadlock and prevention
The four Coffman conditions are mutual exclusion, hold-and-wait, no pre-emption, and circular wait. Two transfers can deadlock if thread A locks account A then waits for B while thread B locks B then waits for A. Prevent circular wait by assigning each account a unique ID and always acquiring the lower-ID lock before the higher-ID lock. Both transfer directions then use the same global lock order.

### Alternatives and complexity
`ArrayBlockingQueue<Integer>(5)` provides a bounded, thread-safe queue with blocking `put` and `take`; it is generally less error-prone than manual `wait/notify`. Queue operations are O(1) in typical implementation, and the buffer uses O(5) space.

`ReentrantLock.tryLock(timeout)` can prevent indefinite waiting by allowing a transfer to abandon/retry if both locks cannot be acquired in time. A transfer takes O(1) bookkeeping plus lock wait/retry time. Lock ordering is simpler and avoids deadlock without repeated retries; timed `tryLock` is useful when timeout-based failure handling is required.

---

## Q7 – Concurrent Fault-Tolerant Result Processor

### Stage 1 – requirements and parallelism
Each score file can be read, validated, and processed independently. Shared data is the result summary. Failures include missing files, unreadable files, empty files, non-numeric scores, and out-of-range scores. Each failed file must be recorded and must not cancel unrelated tasks.

Measurable requirements:
1. Every discovered/submitted file produces exactly one success or failure result.
2. A failed file does not stop other files.
3. Final success + failure count equals submitted file count.
4. All tasks finish or are cancelled after a defined shutdown timeout.
5. Summary is printed only after all submitted futures are collected.

### Stage 2 – design
```text
ResultProcessor
  ├── ExecutorService (fixed pool)
  ├── ScoreTask implements Callable<Result>
  ├── Future<Result> for each input
  └── ConcurrentLinkedQueue<Result> (thread-safe result collection)
```

Pseudocode:
```text
list input files
create fixed thread pool of p workers
for each input:
    submit Callable that reads and validates one file
    return SuccessResult or FailureResult
for each Future:
    get result and add to concurrent result collection
shutdown executor and await completion
count successes and failures
print complete summary
```

### Stage 3 – implementation and measurement
`Task07/ResultProcessor.java` implements the design. The sample directory contains valid scores, a non-numeric score, an out-of-range score, and the program adds a deliberately missing file. For this five-file-plus-one-missing sample, the hand-checked expected summary is:
- Total: 6
- Success: 3
- Failed: 3

The program prints elapsed milliseconds for its actual run. To measure pools of 1, 2, 4 and 8, parameterize the pool size and run each configuration on the same larger dataset several times. Record raw times from the machine rather than inserting invented benchmark results. The supplied compact demo uses a pool of four.

### Stage 4 – evaluation
A pool near the number of available processors is a reasonable starting point for CPU-heavy validation. For I/O-heavy file reading, a somewhat larger pool may help, but storage throughput and memory can become bottlenecks. More threads do not always improve throughput because of context switching, lock contention, disk limits, and memory use.

The design produces one result per submitted task because each `Future` is collected and each task converts expected file/validation exceptions into a failure result. A remaining limitation is that the sample stores all results in memory; very large workloads may need streaming/persisted summaries and bounded submission.

### Alternative approaches
- `parallelStream()` uses the common ForkJoinPool by default and offers concise parallel processing, but pool configuration and per-file failure isolation are less explicit. Catch exceptions inside the mapping operation and return result objects.
- One thread per file creates 10,000 threads, which has substantial stack/memory and scheduling overhead. Thread-stack memory is approximately number of threads × configured stack size, before object/native overhead.
- A fixed pool uses O(p × stack-size) thread-stack memory for p workers, plus O(n) task/future/result bookkeeping if all 10,000 are queued at once. Total useful work is O(total input bytes); elapsed time is bounded by parallel capacity and I/O/CPU bottlenecks. A bad file is isolated by returning a failure result from its task.

---

## Individual Contribution Record

Complete this table with the real pair members' names and actual work. The assignment requires both students to execute every question.

| Question | Student A – Primary responsibility | Student B – Primary responsibility | Joint |
|---|---|---|---|
| Q1 | Exception hierarchy and catch analysis | Test cases and stack-trace analysis | ATM implementation and review |
| Q2 | Exception hierarchy and propagation | Failure scenarios and chaining evidence | Complete code and review |
| Q3 | Debugging and experimental analysis | Resource design and correctness | Both implementations |
| Q4 | Thread design and life cycle | Scheduling experiments | Thread implementation |
| Q5 | Race-condition reproduction | Synchronization comparison | Booking implementation |
| Q6 | Producer-consumer design | Deadlock analysis/prevention | Both implementations |
| Q7 | Architecture and pseudocode | Implementation and measurements | Evaluation and verification |

## Final submission checklist
- [ ] Actual partner name and contribution record entered.
- [ ] Actual Java version recorded (`java -version`).
- [ ] Every program compiled and executed by both students.
- [ ] Genuine output screenshots added to the corresponding task folders.
- [ ] Q4 ten-run output-order table added.
- [ ] Q5 unsynchronized-versus-synchronized ten-run evidence added.
- [ ] Q7 timing measurements for pool sizes 1, 2, 4 and 8 added.
- [ ] GitHub repository created and faculty access configured.
- [ ] Working GitHub link added to this report and cover page.
