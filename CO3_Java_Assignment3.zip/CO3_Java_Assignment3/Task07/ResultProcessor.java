import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class ResultProcessor {
    static class Result {
        final String file; final boolean success; final int score; final String message;
        Result(String file, boolean success, int score, String message) {
            this.file=file; this.success=success; this.score=score; this.message=message;
        }
        public String toString() {
            return file + " | " + (success ? "SUCCESS score=" + score : "FAILED: " + message);
        }
    }

    static class ScoreTask implements Callable<Result> {
        private final Path file;
        ScoreTask(Path file) { this.file = file; }
        public Result call() {
            try {
                if (!Files.exists(file)) throw new NoSuchFileException(file.toString());
                List<String> lines = Files.readAllLines(file);
                if (lines.isEmpty()) throw new IOException("Empty score file");
                int score = Integer.parseInt(lines.get(0).trim());
                if (score < 0 || score > 100) throw new IllegalArgumentException("Score must be 0..100");
                return new Result(file.getFileName().toString(), true, score, "validated");
            } catch (Exception e) {
                return new Result(file.getFileName().toString(), false, 0,
                        e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        }
    }

    static void run(Path directory, int poolSize) throws Exception {
        List<Path> files = new ArrayList<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(directory, "*.txt")) {
            for (Path p : stream) files.add(p);
        }
        ExecutorService pool = Executors.newFixedThreadPool(poolSize);
        ConcurrentLinkedQueue<Result> results = new ConcurrentLinkedQueue<>();
        List<Future<Result>> futures = new ArrayList<>();
        long start = System.nanoTime();
        try {
            for (Path file : files) futures.add(pool.submit(new ScoreTask(file)));
            for (Future<Result> future : futures) {
                try { results.add(future.get()); }
                catch (ExecutionException e) {
                    results.add(new Result("unknown", false, 0, "Task failed: " + e.getCause()));
                }
            }
        } finally {
            pool.shutdown();
            if (!pool.awaitTermination(30, TimeUnit.SECONDS)) pool.shutdownNow();
        }
        long elapsedMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - start);
        long ok = results.stream().filter(r -> r.success).count();
        long failed = results.size() - ok;
        System.out.println("Pool size: " + poolSize);
        results.stream().sorted(Comparator.comparing(r -> r.file)).forEach(System.out::println);
        System.out.println("Summary: total=" + results.size() + ", success=" + ok + ", failed=" + failed);
        System.out.println("Elapsed ms: " + elapsedMs);
    }

    public static void main(String[] args) throws Exception {
        Path dir = args.length > 0 ? Paths.get(args[0]) : Paths.get("Task07", "input");
        Files.createDirectories(dir);
        if (!Files.exists(dir.resolve("student01.txt"))) Files.write(dir.resolve("student01.txt"), Arrays.asList("88"));
        if (!Files.exists(dir.resolve("student02.txt"))) Files.write(dir.resolve("student02.txt"), Arrays.asList("73"));
        if (!Files.exists(dir.resolve("student03.txt"))) Files.write(dir.resolve("student03.txt"), Arrays.asList("not-a-number"));
        if (!Files.exists(dir.resolve("student04.txt"))) Files.write(dir.resolve("student04.txt"), Arrays.asList("145"));
        if (!Files.exists(dir.resolve("student05.txt"))) Files.write(dir.resolve("student05.txt"), Arrays.asList("91"));
        // A deliberately missing file is submitted as a task to demonstrate fault isolation.
        List<Path> inputs = new ArrayList<>();
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir, "*.txt")) {
            for (Path p : ds) inputs.add(p);
        }
        inputs.add(dir.resolve("missing-student.txt"));
        ExecutorService pool = Executors.newFixedThreadPool(4);
        ConcurrentLinkedQueue<Result> results = new ConcurrentLinkedQueue<>();
        List<Future<Result>> futures = new ArrayList<>();
        long start = System.nanoTime();
        try {
            for (Path p : inputs) futures.add(pool.submit(new ScoreTask(p)));
            for (Future<Result> f : futures) results.add(f.get());
        } finally {
            pool.shutdown();
            if (!pool.awaitTermination(30, TimeUnit.SECONDS)) pool.shutdownNow();
        }
        long ok = results.stream().filter(r -> r.success).count();
        long failed = results.size() - ok;
        System.out.println("Pool size: 4");
        results.stream().sorted(Comparator.comparing(r -> r.file)).forEach(System.out::println);
        System.out.println("Summary: total=" + results.size() + ", success=" + ok + ", failed=" + failed);
        System.out.println("Elapsed ms: " + TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-start));
    }
}
