import java.io.*;
import java.nio.file.*;
import java.util.*;

public class SalesReport {
    // Safe implementation: every opened resource is closed even if reading/writing fails.
    static void generateWithResources(List<Path> inputs, Path output) throws IOException {
        long total = 0;
        try (BufferedWriter writer = Files.newBufferedWriter(output);
             BufferedReader log = Files.newBufferedReader(inputs.get(0))) {
            writer.write("DAILY SALES SUMMARY\n");
            for (Path file : inputs) {
                System.out.println("Reading: " + file);
                try (BufferedReader reader = Files.newBufferedReader(file)) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        try { total += Long.parseLong(line.trim()); }
                        catch (NumberFormatException ex) {
                            throw new IOException("Invalid sales value in " + file + ": " + line, ex);
                        }
                    }
                } catch (IOException ex) {
                    System.err.println("Failed file: " + file + " – " + ex.getMessage());
                    throw ex;
                }
            }
            writer.write("Total sales: " + total);
            writer.newLine();
        }
    }

    // Demonstration of the fragile pattern: if an exception occurs before close(), a reader leaks.
    static void generateManual(List<Path> inputs, Path output) throws IOException {
        long total = 0;
        BufferedWriter writer = null;
        List<BufferedReader> opened = new ArrayList<>();
        try {
            writer = Files.newBufferedWriter(output);
            writer.write("DAILY SALES SUMMARY\n");
            for (Path file : inputs) {
                BufferedReader reader = Files.newBufferedReader(file);
                opened.add(reader);
                String line;
                while ((line = reader.readLine()) != null) total += Long.parseLong(line.trim());
                reader.close();
                opened.remove(reader);
            }
            writer.write("Total sales: " + total);
            writer.newLine();
        } finally {
            // A robust finally must close all resources, not just the last one.
            for (BufferedReader reader : opened) {
                try { reader.close(); } catch (IOException closeError) {
                    System.err.println("Close failed: " + closeError.getMessage());
                }
            }
            if (writer != null) writer.close();
        }
    }

    public static void main(String[] args) throws Exception {
        Path dir = Paths.get("Task03", "input");
        Files.createDirectories(dir);
        Path a = dir.resolve("store1.txt"), b = dir.resolve("store2.txt");
        if (!Files.exists(a)) Files.write(a, Arrays.asList("100", "200"));
        if (!Files.exists(b)) Files.write(b, Arrays.asList("150", "250"));
        List<Path> inputs = Arrays.asList(a, b);
        generateManual(inputs, dir.resolve("manual-report.txt"));
        generateWithResources(inputs, dir.resolve("safe-report.txt"));
        System.out.println("Both reports generated. Expected total sales: 700");
    }
}
