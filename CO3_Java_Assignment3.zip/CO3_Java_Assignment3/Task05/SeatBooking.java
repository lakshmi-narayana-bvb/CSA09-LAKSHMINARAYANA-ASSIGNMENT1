import java.util.concurrent.atomic.AtomicInteger;

public class SeatBooking {
    private final boolean[] booked;
    private int bookingsMade = 0;

    SeatBooking(int seats) { booked = new boolean[seats]; }

    // TODO 1 completed: synchronization makes check-then-book atomic on this instance.
    public synchronized boolean book(int seat) {
        if (seat < 0 || seat >= booked.length) throw new IllegalArgumentException("Invalid seat");
        if (booked[seat]) return false;
        booked[seat] = true;
        bookingsMade++;
        return true;
    }

    public static void main(String[] args) throws InterruptedException {
        SeatBooking screen = new SeatBooking(10);
        Thread[] users = new Thread[100];
        AtomicInteger successfulAttempts = new AtomicInteger();
        for (int i = 0; i < users.length; i++) {
            final int seat = i % 10;
            users[i] = new Thread(() -> {
                if (screen.book(seat)) successfulAttempts.incrementAndGet();
            });
            users[i].start();
        }
        for (Thread t : users) t.join();
        System.out.println("Seats sold: " + screen.bookingsMade);
        System.out.println("Successful booking calls: " + successfulAttempts.get());
    }
}
